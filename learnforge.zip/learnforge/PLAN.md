# LearnForge — Implementation Plan

Turn any Udemy course (videos + articles) into a reactive, project-based,
"build-while-explaining" learning experience. An AI ingests the course content,
rebuilds it as hands-on projects, audits itself for omissions, repairs weak
explanations, and tracks progress through milestone projects.

Legend: [x] = executed in this repo, [~] = partially / stubbed, [ ] = future work.

---------------------------------------------------------------------------
## 0. PRODUCT DEFINITION
---------------------------------------------------------------------------

### 0.1 One-sentence pitch
Give LearnForge a course; get back a playable, project-driven curriculum where
every concept in the original course is taught by building something.

### 0.2 Target users
- Self-taught developers who finish Udemy videos but retain little.
- Learners who want to "do" instead of "watch".
- Course owners who want a companion workbook for their own course.

### 0.3 Hard requirements (from the brief)
1. Input: a Udemy course with its videos and articles.
2. Output: reactive, fun, project-based learning.
3. Teaching style: build-while-explaining (explain a bit, build a bit, repeat).
4. Nothing from the source course may be dropped (full coverage).
5. If an explanation is weak or a topic is missing, the AI fixes/fills it.
6. Use GSAP and modern design techniques for polish and engagement.
7. Track progress.
8. Include milestone projects.

### 0.4 Honest constraints (decided up front)
- Udemy videos are DRM-protected and Udemy has no public content API.
  LearnForge therefore does NOT scrape or download videos. The user supplies
  the course *text*: transcripts/captions (.vtt/.srt/.txt), article text
  (.md/.html/.txt), or pasted content. Ingestion is file/paste based.
- Video-only visual content (screen demos) is lost unless the transcript
  mentions it; the gap analyzer flags such moments ("see on screen") so the
  AI can re-explain them in text and code.
- AI calls need an Anthropic API key. Without one the app runs in "offline
  mode" using a deterministic heuristic generator so the whole UX is testable.
- Only content the user is entitled to use should be ingested. The UI says so.

### 0.5 Non-goals (v1)
- Hosting video, user accounts, payments, multi-user sync.
- Running arbitrary learner code on the server (v1 uses in-browser display only).

---------------------------------------------------------------------------
## 1. ARCHITECTURE
---------------------------------------------------------------------------

### 1.1 Stack
- Frontend: Vite + React 18 + TypeScript.
- Animation: GSAP 3 (core, ScrollTrigger, Flip, TextPlugin, SplitText-free
  manual splitting so we stay on the free build).
- State: Zustand with `persist` (progress lives in localStorage).
- Styling: hand-written CSS with custom properties (design tokens),
  glassmorphism, gradient mesh backgrounds, bento grid, dark/light theme.
- Backend: Node 22 + Express, JSON-file persistence in `server/data/`.
- AI: `@anthropic-ai/sdk`, model id from env (`LF_MODEL`, default
  `claude-sonnet-5-5`).
- Dev: `concurrently` runs Vite and the API; Vite proxies `/api`.

### 1.2 Repo layout
```
learnforge/
  PLAN.md                  this file
  README.md                quickstart
  package.json
  vite.config.ts
  tsconfig.json
  index.html
  shared/types.ts          domain types used by both sides
  server/
    index.ts               express app, routes
    store.ts               JSON persistence
    ingest/
      parse.ts             vtt/srt/html/md/txt -> clean text
      structure.ts         files -> Course/Section/Lecture
    ai/
      client.ts            anthropic wrapper, retries, JSON repair
      prompts.ts           all prompt templates
      analyze.ts           concept ledger + gap detection
      design.ts            curriculum + projects + milestones
      lesson.ts            build-while-explaining lesson generator
      audit.ts             coverage audit + repair loop
      offline.ts           heuristic generator (no API key)
      pipeline.ts          orchestrates stages, emits progress events
    data/                  runtime JSON (gitignored)
  src/
    main.tsx
    App.tsx
    store/useStore.ts      progress, xp, streak, settings
    api.ts                 fetch helpers + SSE client
    lib/gsapSetup.ts       plugin registration, shared timelines
    lib/xp.ts              xp/level math
    lib/confetti.ts        canvas confetti (gsap-driven)
    styles/tokens.css
    styles/app.css
    components/
      Shell.tsx            layout, nav, theme toggle
      MeshBackground.tsx   animated gradient mesh
      Dashboard.tsx        course cards, global stats
      Importer.tsx         upload/paste, structure editor
      PipelineView.tsx     live generation progress
      CoursePath.tsx       journey map with milestones
      LessonPlayer.tsx     split pane build-while-explaining
      StepCard.tsx
      CodeBlock.tsx
      Quiz.tsx
      MilestoneProject.tsx
      CoverageMap.tsx      concept coverage + AI-fixed badges
      ProgressRing.tsx
      XPBar.tsx
      Toasts.tsx
  scripts/
    smoke.mjs              end-to-end API test (offline mode)
```

### 1.3 Data flow
1. User creates a course, adds lectures (files/paste), orders them.
2. Server parses + normalizes -> `Course` (sections, lectures, clean text).
3. Pipeline stage A (analyze): per lecture -> concepts + weak spots.
4. Stage B (design): concepts -> modules, each with a project slice;
   every N modules -> a milestone project.
5. Stage C (lessons): per module -> ordered steps (explain / build / check).
6. Stage D (audit): verify every concept id is covered by >=1 step;
   missing -> regenerate targeted steps; weak -> add "AI reinforcement".
7. Server stores `Curriculum`; client streams progress via SSE.
8. Learner plays lessons; progress persisted client side; milestones unlock.

---------------------------------------------------------------------------
## 2. DOMAIN MODEL (shared/types.ts)
---------------------------------------------------------------------------

### 2.1 Source types
- `Lecture { id, sectionId, title, kind: 'video'|'article', text, order }`
- `Section { id, title, order, lectureIds }`
- `Course { id, title, description, sections, lectures, createdAt }`

### 2.2 Analysis types
- `Concept { id, lectureId, name, summary, sourceQuote, difficulty 1-5,
  quality: 'solid'|'thin'|'missing-context' }`
- `Gap { id, lectureId, kind: 'thin'|'visual-only'|'undefined-term'|
  'missing-prereq'|'error', note }`
- `Analysis { concepts: Concept[], gaps: Gap[] }`

### 2.3 Curriculum types
- `Module { id, title, goal, projectSlice, conceptIds, stepIds, xp }`
- `Milestone { id, title, brief, afterModuleId, requirements[], rubric[],
  conceptIds, xp }`
- `Step { id, moduleId, type: 'explain'|'build'|'check'|'reflect',
  title, body(markdown), code?, language?, task?, hints[], quiz?,
  conceptIds, origin: 'course'|'ai-fix', xp }`
- `Curriculum { courseId, modules, milestones, steps, coverage }`
- `Coverage { conceptId -> stepIds[], fixed: conceptIds[], score 0..1 }`

### 2.4 Progress types (client)
- `Progress { completedSteps, quizAnswers, milestoneStatus, xp, streak,
  lastActive, hintsUsed, notes }`

---------------------------------------------------------------------------
## 3. INGESTION
---------------------------------------------------------------------------

### 3.1 Accepted inputs
- `.vtt` / `.srt` caption files -> strip timestamps, cue numbers, tags.
- `.txt` / `.md` -> normalized as is.
- `.html` -> strip scripts/styles/tags, keep headings and code blocks.
- Pasted text with optional `# Section` / `## Lecture` markers.
- Bulk upload: filenames like `03 - Variables.vtt` are sorted naturally and
  grouped by numeric prefix or folder-style prefixes `S02_L05`.

### 3.2 Cleaning rules
1. Remove WEBVTT headers, NOTE blocks, cue ids, timestamps.
2. Merge caption fragments into sentences (join lines, fix hyphen splits).
3. De-duplicate rolling captions (YouTube style repeated lines).
4. Collapse whitespace, normalize quotes, keep fenced code verbatim.
5. Detect `kind`: .vtt/.srt -> video, others -> article (user can override).
6. Reject empty lectures; warn when under 40 words.

### 3.3 Structure inference
- If pasted with markers use them.
- Else use filename prefixes; else one section "Course" with ordered lectures.
- User can rename, reorder (drag), move lectures between sections, change kind.

### 3.4 Validation
- Max 400 KB per lecture, 25 MB per course (configurable).
- Chunking: lectures over ~6k tokens are split into overlapping chunks for
  analysis, then merged by concept name.

---------------------------------------------------------------------------
## 4. AI PIPELINE — DETAILED STAGES
---------------------------------------------------------------------------

### 4.1 Principles
- Never let the model "summarize away" content: every stage keeps source
  references (`lectureId`, `sourceQuote`).
- Structured output: ask for JSON only; validate; repair; retry up to 3x.
- Deterministic ids generated server-side, not by the model.
- Each stage is idempotent and cached by content hash so edits only redo
  affected lectures.
- All prompts live in `prompts.ts` for easy tuning.

### 4.2 Stage A — Concept ledger (analyze.ts)
Input: one lecture (chunked if long) + course title + list of previous
concept names (for context).
Output: JSON `{ concepts: [...], gaps: [...] }`.
Instructions to the model:
- List EVERY teachable item: definitions, syntax, commands, patterns,
  gotchas, tips, examples, analogies, stated best practices.
- Quote the shortest source snippet that proves each item.
- Mark quality `thin` if the instructor mentions but does not explain;
  `missing-context` if it relies on an undefined prerequisite.
- Emit `gaps` for: "as you can see on screen", undefined jargon, skipped
  steps, factual errors, outdated API usage.
Post-processing: merge duplicates by normalized name, assign ids `c_001...`.

### 4.3 Stage B — Curriculum design (design.ts)
Input: ordered concepts + gaps + course meta.
Goals:
- Choose ONE continuous "spine project" (or 3-5 themed mini-projects) that
  can naturally exercise all concepts. Prefer the project the course itself
  builds, if any.
- Cut the course into modules of 4-9 concepts each, following original order
  unless prerequisites demand otherwise.
- Each module gets a `projectSlice`: the feature added to the spine project.
- Every 3rd module (configurable) ends with a milestone project that
  integrates all prior modules, with requirements + rubric.
- Add a final capstone milestone.
Output validated: every concept id appears in exactly one module.

### 4.4 Stage C — Lesson generation (lesson.ts)
For each module produce 6-14 steps following the loop:
1. EXPLAIN (short, <=120 words): the one idea needed right now, with an
   analogy when the source used one.
2. BUILD: a concrete task, starter code, expected result, 1-3 progressive
   hints. Code grows the spine project cumulatively.
3. CHECK: 1 quiz question (mcq or predict-output) tied to the concept.
4. REFLECT (every module end): "what did you build, what broke".
Rules in the prompt:
- Teach by building: no step may explain more than ~120 words before the
  learner has something to do.
- Keep original terminology and examples from the source when they exist.
- Cite which concepts each step covers (`conceptIds`).
- For `thin`/`missing-context` concepts, add an extra step with
  `origin: 'ai-fix'` that explains properly (what, why, example, pitfall).

### 4.5 Stage D — Coverage audit and repair (audit.ts)
1. Compute coverage map from steps.
2. Uncovered concepts -> targeted regeneration prompt, produce steps,
   insert into the best module (nearest by source order).
3. Weak coverage (concept only mentioned in an explain step, no build or
   check) -> add a build/check step.
4. Second-opinion pass: model reviews each module's steps against the
   original lecture text and lists omissions; fix once more.
5. Final score = covered / total; the UI shows it and refuses to mark a
   curriculum "complete" below 100% (it shows what is missing).

### 4.6 Self-repair of weak course content
- Gaps of kind `error` produce a "Heads up" callout in the step with the
  corrected information and a note that the source differs.
- `visual-only` gaps produce a step that reconstructs the visual as code or
  an ASCII/diagram description.
- `undefined-term` gaps produce a mini-glossary entry attached to a step.
- `missing-prereq` gaps insert a short prerequisite step before first use.
- All such steps are badged "AI-fixed" in the UI and listed in the
  coverage map so learners see where the AI improved the course.

### 4.7 Reliability
- Exponential backoff on 429/5xx. Concurrency limit (default 3).
- JSON extraction: find first `{`..last `}`, strip code fences, retry with
  "your previous output was invalid JSON" message.
- Token budget guard: estimate tokens (chars/4) and chunk accordingly.
- Progress events: `{stage, current, total, message}` via SSE.
- Cancellation via AbortController on client disconnect.

### 4.8 Offline mode (no API key)
- Heuristic analyzer: sentence scoring, headings, code-fence and "term is"
  patterns, bullet detection become concepts.
- Heuristic designer: chunk by sections, milestone every 3 modules.
- Heuristic lesson builder: explain from source sentences, build tasks from
  code blocks (or "write it in your own words" tasks), generated quiz
  (cloze deletion).
- Purpose: tests, demos, and graceful degradation. Clearly labelled.

---------------------------------------------------------------------------
## 5. PEDAGOGY RULES (build-while-explaining)
---------------------------------------------------------------------------
1. The learner touches something within 60 seconds of reading.
2. One new idea per step.
3. Every explanation is followed by an action that uses it.
4. Projects are cumulative: step N's code is the base for step N+1.
5. Failure is designed in: some build steps include a "break it on purpose"
   task to teach error messages.
6. Retrieval practice: spaced quiz resurfacing of earlier concepts at
   module boundaries.
7. Hints are progressive (nudge -> pattern -> near-answer).
8. Milestones demand integration without hand-holding.
9. Reflection prompts at module end consolidate learning.
10. Tone: friendly, concrete, no filler.

---------------------------------------------------------------------------
## 6. FRONTEND EXPERIENCE
---------------------------------------------------------------------------

### 6.1 Design system
- Tokens: spacing scale 4/8/12/16/24/32/48, radii 8/14/22, shadow layers,
  color roles (bg, surface, text, muted, brand, accent, success, warn).
- Palette: deep indigo base, electric violet + cyan accents, warm amber for
  XP/reward moments.
- Typography: Inter (system fallback), tabular numerals for stats,
  fluid `clamp()` sizes, monospace JetBrains Mono / ui-monospace for code.
- Surfaces: glass cards (backdrop blur, 1px inner border, soft glow).
- Layout: bento grid on dashboard; split pane in the lesson player.
- Theme: `prefers-color-scheme` + manual toggle, stored.
- Accessibility: focus rings, AA contrast, `prefers-reduced-motion`
  disables non-essential GSAP motion, keyboard shortcuts, aria-live toasts.
- Responsive: single column <820px, bottom action bar on mobile.

### 6.2 GSAP motion language
- Page enter: staggered `from` with `autoAlpha`, y 24, `power3.out`.
- Mesh background: slow-moving blurred blobs via looping timelines.
- Dashboard cards: ScrollTrigger reveal + hover tilt via `quickTo`.
- Numbers: count-up on XP, progress percentages (`gsap.to` on object).
- Progress rings: `strokeDashoffset` tweens with elastic finish.
- Step transitions: Flip between collapsed and focused step states.
- Typewriter: TextPlugin for the AI "thinking" lines in pipeline view.
- Pipeline view: stage rail animates, active node pulses, log lines slide in.
- Journey map: path drawn with `strokeDashoffset`, nodes pop with `back.out`,
  milestone nodes get a continuous gentle float + glow pulse.
- Rewards: confetti burst (canvas, gsap ticker), XP toast flies to the XP bar,
  level-up full-screen moment with timeline sequence.
- Quiz feedback: shake on wrong, bounce + glow on right.
- Micro-interactions: magnetic buttons, ripple, cursor-follow glow.

### 6.3 Screens
1. Dashboard: stats strip (XP, level, streak, steps done), course cards with
   rings, "Resume" hero card, create-course CTA.
2. Importer: drop zone, paste area, structure editor with reorder and kind
   toggle, "Forge course" button.
3. Pipeline: live stages (Parse -> Analyze -> Design -> Lessons -> Audit),
   streaming log, coverage gauge filling to 100%.
4. Course path: vertical journey map with modules, milestone gates, lock
   states, progress, coverage tab.
5. Lesson player: left = explanation + steps rail; right = build workspace
   (starter code, task, hints, editor textarea, "run check" self-verify via
   checklist); bottom = quiz and next.
6. Milestone: brief, requirements checklist, rubric self-assessment, notes
   field, submit -> celebrate.
7. Coverage map: grid of concepts coloured by status, AI-fixed badges,
   click to see where it's taught and the original quote.
8. Settings: API key status, model, theme, reduced motion, reset progress.

### 6.4 Progress and gamification
- XP per step by type (explain 5, build 15, check 10, reflect 5), bonus for
  no hints and first-try quiz, milestones 100-300.
- Level = floor(sqrt(xp/50)) + 1, with smooth XP bar.
- Streak: consecutive days with >=1 completed step.
- Badges: First Build, Streak 3/7, Module Master, Milestone Maker,
  Zero Hints, Completionist.
- Unlocking: modules sequential; milestone unlocks after its modules; the
  next module unlocks after a milestone is submitted (self-assessed).
- Persistence: localStorage via Zustand persist, versioned, exportable.

---------------------------------------------------------------------------
## 7. API SPEC
---------------------------------------------------------------------------
- `GET  /api/health` -> `{ ok, aiMode: 'claude'|'offline', model }`
- `GET  /api/courses` -> list
- `POST /api/courses` `{ title, description, lectures: [...] }` -> course
- `POST /api/ingest` multipart files -> parsed lectures
- `GET  /api/courses/:id` -> course
- `PUT  /api/courses/:id` update structure
- `DELETE /api/courses/:id`
- `POST /api/courses/:id/forge` -> SSE stream of pipeline events, final
  `done` event contains curriculum
- `GET  /api/courses/:id/curriculum`
- Errors: `{ error: string }` with proper status codes.

---------------------------------------------------------------------------
## 8. EXECUTION CHECKLIST (step by step)
---------------------------------------------------------------------------

### Phase 1 — Scaffold
- [x] 1.1 Create `learnforge/` and `package.json` with scripts
      (`dev`, `build`, `start`, `smoke`, `typecheck`).
- [x] 1.2 Install deps: react, react-dom, gsap, zustand, express, multer,
      @anthropic-ai/sdk; dev: vite, @vitejs/plugin-react, typescript, tsx,
      concurrently, @types/*.
- [x] 1.3 `tsconfig.json`, `vite.config.ts` with `/api` proxy.
- [x] 1.4 `index.html` with fonts and root div.
- [x] 1.5 `.gitignore`, `README.md`.

### Phase 2 — Shared types
- [x] 2.1 Write `shared/types.ts` per section 2.
- [x] 2.2 Add helper type guards and id utilities.

### Phase 3 — Server foundation
- [x] 3.1 Express app, JSON body, CORS off (same-origin via proxy).
- [x] 3.2 `store.ts` read/write JSON atomically.
- [x] 3.3 Health route reporting AI mode.
- [x] 3.4 Course CRUD routes.

### Phase 4 — Ingestion
- [x] 4.1 `parse.ts` VTT/SRT cleaner with rolling-caption dedupe.
- [x] 4.2 HTML to text with code preservation.
- [x] 4.3 Markdown/txt normalization.
- [x] 4.4 `structure.ts` natural sort and section inference.
- [x] 4.5 Pasted-text marker parser.
- [x] 4.6 `/api/ingest` multipart route.

### Phase 5 — AI layer
- [x] 5.1 `client.ts`: SDK wrapper, JSON mode, retries, repair.
- [x] 5.2 `prompts.ts`: analyze, design, lesson, audit-fix, review.
- [x] 5.3 `analyze.ts` with chunking and merging.
- [x] 5.4 `design.ts` with validation (every concept in one module).
- [x] 5.5 `lesson.ts` per-module step generation, AI-fix steps.
- [x] 5.6 `audit.ts` coverage computation and repair loop.
- [x] 5.7 `offline.ts` heuristic equivalents of 5.3-5.6.
- [x] 5.8 `pipeline.ts` orchestration, progress events, caching.
- [x] 5.9 `/forge` SSE route with abort handling.

### Phase 6 — Frontend foundation
- [x] 6.1 Tokens and base CSS, themes, reduced motion.
- [x] 6.2 `gsapSetup.ts` plugin registration, helpers (`reveal`, `countUp`).
- [x] 6.3 Zustand store with persistence and selectors.
- [x] 6.4 `api.ts` including SSE reader.
- [x] 6.5 Shell, MeshBackground, Toasts, XPBar.

### Phase 7 — Screens
- [x] 7.1 Dashboard with stats and course cards.
- [x] 7.2 Importer with drop zone, paste, structure editor.
- [x] 7.3 PipelineView with stage rail, log, coverage gauge.
- [x] 7.4 CoursePath journey map with locks and milestones.
- [x] 7.5 LessonPlayer with steps, hints, quiz, code view.
- [x] 7.6 MilestoneProject view with checklist and rubric.
- [x] 7.7 CoverageMap with concept drilldown.
- [x] 7.8 Settings panel.

### Phase 8 — Delight
- [x] 8.1 Confetti and level-up sequence.
- [x] 8.2 Count-up numbers and ring animations.
- [x] 8.3 Magnetic buttons and card tilt.
- [x] 8.4 Keyboard shortcuts (J/K next/prev, H hint, Enter check).

### Phase 9 — Quality
- [x] 9.1 `npm run typecheck` clean.
- [x] 9.2 `scripts/smoke.mjs` end-to-end in offline mode with a sample
      course (ingest -> forge -> curriculum -> coverage 100%).
- [x] 9.3 Production build passes.
- [x] 9.4 Browser run via Playwright: screenshot dashboard, path, lesson;
      assert no console errors.
- [x] 9.5 Fix everything found.

### Phase 10 — Docs and handoff
- [x] 10.1 README quickstart, env vars, how to export transcripts.
- [x] 10.2 Known limitations and next steps (section 9).

---------------------------------------------------------------------------
## 9. FUTURE WORK
---------------------------------------------------------------------------
- [ ] In-browser code sandbox (Sandpack/WebContainers) with auto-checking.
- [ ] Whisper transcription for video files the user owns.
- [ ] Spaced-repetition scheduler (SM-2) across courses.
- [ ] Cloud sync, accounts, shareable curricula.
- [ ] Browser extension that exports Udemy captions the user can see.
- [ ] Voice narration (TTS) for explain steps.
- [ ] Visual diagram generation for visual-only gaps.
- [ ] Peer review of milestone projects.
- [ ] Analytics on which steps cause hint use or failures to improve prompts.

---------------------------------------------------------------------------
## 10. RISKS AND MITIGATIONS
---------------------------------------------------------------------------
- Model drops content -> concept ledger + audit loop + coverage gate.
- Model invents facts -> prompts require grounding in source quotes; fixes
  are labelled AI-fixed; users can flag/regenerate a step.
- Long courses exceed limits -> chunking, per-module generation, caching.
- Invalid JSON -> repair/retry; fall back to offline heuristics per stage.
- API cost -> caching by hash, concurrency cap, token estimates in UI.
- Copyright -> user-supplied content only, local storage, no redistribution.
- Motion sickness / a11y -> reduced-motion support everywhere.

---------------------------------------------------------------------------
## 11. ACCEPTANCE CRITERIA
---------------------------------------------------------------------------
1. Importing 5+ lectures and forging yields modules, steps and milestones.
2. Coverage score is 100% and every concept links to a step.
3. Steps follow explain -> build -> check, with short explanations.
4. Weak concepts produce steps badged AI-fixed.
5. Progress, XP, streak and milestone unlocks persist across reloads.
6. GSAP animations run; reduced-motion disables them.
7. App works with and without an API key.
8. Typecheck, build and smoke test all pass.

---------------------------------------------------------------------------
## 12. EXECUTION STATUS (honest notes)
---------------------------------------------------------------------------
- Verified: typecheck, production build, offline-mode smoke test (ingest ->
  forge -> 100% coverage -> persisted) and a Playwright run through the whole
  UI (import, forge, journey, every lesson step, capstone) with no console errors.
- NOT verified: Claude mode. It needs ANTHROPIC_API_KEY and was never run
  here; prompts/JSON handling are untested against the live API.
- GSAP: core tweens, timelines, quickTo, elastic/back eases and the ticker are
  used. ScrollTrigger, Flip and TextPlugin are registered but not yet used
  (planned step Flip transitions and typewriter log are future work).
- Offline mode produces plain heuristic lessons; the richness in this plan
  comes from Claude mode.
