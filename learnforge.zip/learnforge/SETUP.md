# LearnForge — Setup Guide

LearnForge turns a course (lecture transcripts + articles) into a hands-on, project-based
course with progress tracking and milestone projects.

## Fastest way (Windows)
Open PowerShell and paste the one-line command you were given, e.g.
```
irm https://YOUR-HOST/install.ps1 | iex
```
It installs Node if needed, downloads LearnForge to `C:\Users\<you>\learnforge`, builds it, then asks how to connect to Claude (subscription login, API key, or offline), sets it up for you, and opens the app.
If PowerShell blocks scripts, run `Set-ExecutionPolicy -Scope Process Bypass` first. To run again later: `cd ~\learnforge; npm start`.

**Linux / macOS** — open a terminal and run (needs `curl` and `unzip`):
```
LEARNFORGE_ZIP=https://YOUR-HOST/learnforge.zip bash -c "$(curl -fsSL https://YOUR-HOST/install.sh)"
```
It does the same things and installs to `~/learnforge`. Later: `cd ~/learnforge && npm start`.

Prefer to do it by hand? Follow steps 1-5 below.

## 1. Install Node.js (once)
You need **Node.js 22 or newer**.
1. Go to https://nodejs.org and download the **LTS/Current 22+** installer. Install it with the defaults.
2. Open a terminal (macOS: *Terminal*; Windows: *PowerShell*) and check:
   ```
   node -v     # should print v22.x or higher
   npm -v
   ```

## 2. Unpack the project
Unzip `learnforge.zip`, then open a terminal inside the `learnforge` folder:
```
cd path/to/learnforge
```

## 3. Install and build
```
npm run setup
```
This installs dependencies and builds the app (takes about a minute).

## 4. (Optional) Turn on the AI
Without a key the app runs in **offline mode** (simple, rule-based lessons — fine for a demo).
For real AI-written lessons you need an Anthropic API key (https://console.anthropic.com → API keys; usage is billed to that account).
1. Copy `.env.example` to `.env` (macOS/Linux: `cp .env.example .env`; Windows: `copy .env.example .env`).
2. Open `.env` and paste your key after `ANTHROPIC_API_KEY=`.
Keep this file private; never share or upload it.

**No API key? Use your Claude Pro/Max subscription instead (for your own computer):**
1. `npm install -g @anthropic-ai/claude-code`, then run `claude` once and log in.
2. In `.env` add the line `LF_PROVIDER=claude-code`.
Forging then uses your subscription's usage allowance (long courses may hit limits). Use your own login only; don't share it.

## 5. Start it
```
npm start
```
Open **http://localhost:8787**. The badge at the top shows **● Claude** (AI on) or **● Offline mode**.
Stop with `Ctrl+C`.

## 6. Use it
1. Click **Forge a new course**.
2. Give it a title and add material:
   - drop caption/transcript files (`.vtt`, `.srt`), articles (`.txt`, `.md`, `.html`), or
   - paste text, using `# Section` and `## Lecture` lines to structure it.
   Tip: name files like `S01_L02 - Variables.vtt` so they sort into sections.
3. Reorder or rename lectures, then click **⚒ Forge course** and wait for the stages to finish.
4. Open the **Journey**, press **Start building**, and work through explain → build → check steps.
   Finish modules to unlock milestone projects. Shortcuts: `J` next, `K` back, `H` hint.
5. The **Coverage map** tab shows every concept found in your course and where it is taught.

## Getting the course text
Udemy videos are DRM-protected and Udemy has no content API, so LearnForge does not download anything.
Use transcripts/captions and articles you already have legitimate access to (for example, text
you copy from the course, or captions you are permitted to export). Only use content you're entitled to use.

## Developer mode (optional)
`npm run dev` runs hot-reloading at http://localhost:5173. `npm run smoke` runs an end-to-end test.

## Troubleshooting
| Problem | Fix |
|---|---|
| `node -v` shows a version below 22 | Reinstall Node from nodejs.org |
| Page won't load | Make sure `npm start` is still running and you ran `npm run setup` first |
| "Port already in use" | Set `PORT=8800` in `.env`, then open that port |
| Badge says Offline mode | Check `.env` exists (not `.env.txt`), has the key, and restart `npm start` |
| AI errors / slow forging | Long courses take several minutes; check your API credit balance |

Your courses are stored in `server/data/`. Progress and XP are stored in your browser, so use the same browser to continue.
