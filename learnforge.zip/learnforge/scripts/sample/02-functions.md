# Functions

A function is a reusable block of code that performs one task.

```js
function greet(name) { return "Hi " + name; }
```

A parameter is a placeholder that receives a value when the function is called.

The return keyword sends a result back to the caller.

Arrow functions are a shorter syntax for writing functions.
