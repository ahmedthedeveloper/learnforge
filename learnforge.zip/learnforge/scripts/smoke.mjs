import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';

const port = 8799, base = `http://localhost:${port}`;
const data = fs.mkdtempSync(path.join(os.tmpdir(), 'lf-'));
const env = { ...process.env, PORT: String(port), LF_DATA: data, ANTHROPIC_API_KEY: '' };
const srv = spawn('node', ['--import', 'tsx', 'server/index.ts'], { env, stdio: 'inherit' });
const fail = (m) => { console.error('SMOKE FAIL:', m); srv.kill(); process.exit(1); };
const ok = (c, m) => (c ? console.log('ok -', m) : fail(m));

for (let i = 0; i < 60; i++) { try { if ((await fetch(base + '/api/health')).ok) break; } catch {} await new Promise((r) => setTimeout(r, 250)); }

const dir = 'scripts/sample';
const form = new FormData();
for (const f of fs.readdirSync(dir)) form.append('files', new Blob([fs.readFileSync(path.join(dir, f))]), f);
const ing = await (await fetch(base + '/api/ingest', { method: 'POST', body: form })).json();
ok(ing.lectures.length === 3, 'ingested 3 lectures');
ok(!ing.lectures.some((l) => /-->|WEBVTT/.test(l.text)), 'captions cleaned');
ok(ing.lectures[0].kind === 'video', 'vtt detected as video');

const course = await (await fetch(base + '/api/courses', {
  method: 'POST', headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ title: 'JS Basics', description: 'sample', ...ing }),
})).json();
ok(course.id, 'course created');

const res = await fetch(`${base}/api/courses/${course.id}/forge`, { method: 'POST' });
const text = await res.text();
const events = text.split('\n\n').filter(Boolean).map((b) => JSON.parse(b.replace(/^data: /, '')));
const done = events.find((e) => e.stage === 'done');
ok(done, 'pipeline finished');
const cur = done.curriculum;
ok(cur.coverage.score === 1, `coverage 100% (${cur.concepts.length} concepts)`);
ok(cur.modules.length >= 1 && cur.milestones.length >= 1, `${cur.modules.length} modules, ${cur.milestones.length} milestones`);
ok(cur.modules.every((m) => m.stepIds.length && cur.steps.some((s) => s.moduleId === m.id && s.type === 'reflect')), 'every module has steps + reflect');
ok(cur.steps.every((s) => s.type !== 'check' || s.quiz), 'check steps have quizzes');
ok(cur.steps.some((s) => s.origin === 'ai-fix'), 'thin concepts reinforced');
ok(new Set(cur.steps.map((s) => s.id)).size === cur.steps.length, 'unique step ids');
ok(cur.milestones.at(-1).moduleIds.includes(cur.modules.at(-1).id), 'capstone closes course');
const again = await (await fetch(`${base}/api/courses/${course.id}/curriculum`)).json();
ok(again.courseId === course.id, 'curriculum persisted');
console.log('ALL SMOKE CHECKS PASSED');
srv.kill();
process.exit(0);
