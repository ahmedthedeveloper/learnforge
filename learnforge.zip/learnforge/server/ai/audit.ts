import type { Analysis, Coverage, Course, Step } from '../../shared/types';
import { xpFor, generateFixSteps, type StepDraft } from './lesson';
import { offlineQuiz } from './offline';
import type { Design } from './design';

export function computeCoverage(a: Analysis, steps: Step[]): Coverage {
  const map: Record<string, string[]> = {};
  for (const c of a.concepts) map[c.id] = [];
  for (const s of steps) for (const id of s.conceptIds) map[id]?.push(s.id);
  const missing = a.concepts.filter((c) => !map[c.id].length).map((c) => c.id);
  const fixed = a.concepts.filter((c) => steps.some((s) => s.origin === 'ai-fix' && s.conceptIds.includes(c.id))).map((c) => c.id);
  const score = a.concepts.length ? (a.concepts.length - missing.length) / a.concepts.length : 1;
  return { map, fixed, missing, score };
}

/** Assign ids to drafts and append them to a module. */
export function addSteps(steps: Step[], d: Design, moduleId: string, drafts: StepDraft[], at?: number) {
  const mod = d.modules.find((m) => m.id === moduleId)!;
  const made = drafts.map((x): Step => ({ ...x, id: `st_${steps.length + 1 + drafts.indexOf(x)}`, moduleId, xp: xpFor(x.type) }));
  // ids must be unique even when inserting: derive from a running counter
  let n = steps.reduce((m, s) => Math.max(m, +s.id.slice(3)), 0);
  made.forEach((s) => { s.id = `st_${++n}`; });
  steps.push(...made);
  const ids = made.map((s) => s.id);
  if (at === undefined) mod.stepIds.push(...ids); else mod.stepIds.splice(at, 0, ...ids);
}

/** Repair loop: fill uncovered concepts, then ensure each concept is practised (build or check), not just explained. */
export async function auditAndRepair(course: Course, a: Analysis, d: Design, steps: Step[], signal?: AbortSignal) {
  for (let pass = 0; pass < 2; pass++) {
    const cov = computeCoverage(a, steps);
    if (!cov.missing.length) break;
    const byModule = new Map<string, typeof a.concepts>();
    for (const id of cov.missing) {
      const mod = d.modules.find((m) => m.conceptIds.includes(id))!;
      byModule.set(mod.id, [...(byModule.get(mod.id) ?? []), a.concepts.find((c) => c.id === id)!]);
    }
    for (const [modId, cs] of byModule) {
      const drafts = await generateFixSteps(course, a, d, cs, signal);
      const mod = d.modules.find((m) => m.id === modId)!;
      const reflectAt = mod.stepIds.findIndex((sid) => steps.find((s) => s.id === sid)?.type === 'reflect');
      addSteps(steps, d, modId, drafts, reflectAt < 0 ? undefined : reflectAt);
    }
  }
  // practice pass: a concept explained but never built/checked gets a check step
  for (const c of a.concepts) {
    const covering = steps.filter((s) => s.conceptIds.includes(c.id));
    if (covering.length && !covering.some((s) => s.type === 'build' || s.type === 'check')) {
      const mod = d.modules.find((m) => m.conceptIds.includes(c.id))!;
      addSteps(steps, d, mod.id, [{
        type: 'check', title: `Check: ${c.name}`, body: 'Quick recall.', hints: [], conceptIds: [c.id],
        origin: 'ai-fix', quiz: offlineQuiz(c, a.concepts),
      }], mod.stepIds.findIndex((sid) => steps.find((s) => s.id === sid)?.type === 'reflect') >= 0
        ? mod.stepIds.findIndex((sid) => steps.find((s) => s.id === sid)?.type === 'reflect') : undefined);
    }
  }
  return computeCoverage(a, steps);
}
