import type { Analysis, Course, Milestone, Module } from '../../shared/types';
import { askJson, hasKey } from './client';
import { designPrompt, SYS } from './prompts';

export const MILESTONE_EVERY = 3;
interface RawDesign {
  spineProject?: string;
  modules?: { title?: string; goal?: string; projectSlice?: string; conceptIds?: string[] }[];
  milestones?: { title?: string; brief?: string; moduleIndexes?: number[]; requirements?: string[]; rubric?: string[] }[];
}
export interface Design { spineProject: string; modules: Module[]; milestones: Milestone[] }

function offlineDesign(course: Course, a: Analysis): RawDesign {
  const lecTitle = new Map(course.lectures.map((l) => [l.id, l.title]));
  const modules: NonNullable<RawDesign['modules']> = [];
  const per = 6;
  for (let i = 0; i < a.concepts.length; i += per) {
    const group = a.concepts.slice(i, i + per);
    const title = lecTitle.get(group[0].lectureId) ?? `Module ${modules.length + 1}`;
    modules.push({
      title, goal: `Understand and use: ${group.map((c) => c.name).slice(0, 3).join(', ')}${group.length > 3 ? '…' : ''}`,
      projectSlice: `Extend your ${course.title} project with ${group[0].name}`, conceptIds: group.map((c) => c.id),
    });
  }
  return { spineProject: `${course.title}: a project you grow module by module`, modules };
}

/** Normalize any design so every concept lands in exactly one module and milestones are well-formed. */
export function normalizeDesign(raw: RawDesign, a: Analysis, course: Course): Design {
  const valid = new Set(a.concepts.map((c) => c.id));
  const placed = new Set<string>();
  const modules: Module[] = [];
  for (const m of raw.modules ?? []) {
    const ids = (m.conceptIds ?? []).filter((id) => valid.has(id) && !placed.has(id));
    ids.forEach((id) => placed.add(id));
    if (!ids.length) continue;
    modules.push({
      id: `m_${modules.length + 1}`, title: m.title || `Module ${modules.length + 1}`, goal: m.goal ?? '',
      projectSlice: m.projectSlice ?? '', conceptIds: ids, stepIds: [],
    });
  }
  const orphans = a.concepts.filter((c) => !placed.has(c.id));
  if (orphans.length) {
    if (!modules.length) modules.push({ id: 'm_1', title: course.title, goal: '', projectSlice: '', conceptIds: [], stepIds: [] });
    // attach each orphan to the module whose concepts are nearest in source order
    for (const o of orphans) {
      const oi = a.concepts.indexOf(o);
      let best = modules[modules.length - 1], bd = Infinity;
      for (const m of modules) for (const id of m.conceptIds) {
        const d = Math.abs(a.concepts.findIndex((c) => c.id === id) - oi);
        if (d < bd) { bd = d; best = m; }
      }
      best.conceptIds.push(o.id);
    }
  }
  const conceptsOf = (idx: number[]) => idx.flatMap((i) => modules[i]?.conceptIds ?? []);
  let ms = (raw.milestones ?? []).map((m) => ({
    ...m, moduleIndexes: (m.moduleIndexes ?? []).filter((i) => i >= 0 && i < modules.length),
  })).filter((m) => m.moduleIndexes.length);
  if (!ms.length) {
    for (let i = 0; i < modules.length; i += MILESTONE_EVERY) {
      const idx = modules.slice(i, i + MILESTONE_EVERY).map((_, k) => i + k);
      ms.push({ title: '', brief: '', moduleIndexes: idx, requirements: [], rubric: [] });
    }
  }
  // the last module must close a milestone (capstone)
  const last = modules.length - 1;
  if (!ms.some((m) => m.moduleIndexes.includes(last))) {
    ms.push({ title: '', brief: '', moduleIndexes: [last], requirements: [], rubric: [] });
  }
  const milestones: Milestone[] = ms.map((m, i) => {
    const idx = [...new Set(m.moduleIndexes)].sort((x, y) => x - y);
    const isCap = i === ms.length - 1;
    const titles = idx.map((k) => modules[k].title);
    return {
      id: `ms_${i + 1}`, title: m.title || (isCap ? `Capstone: ${course.title}` : `Milestone ${i + 1}`),
      brief: m.brief || `Combine what you learned in ${titles.join(', ')} into one working piece of your project, without step-by-step guidance.`,
      afterModuleId: modules[idx[idx.length - 1]].id, moduleIds: idx.map((k) => modules[k].id),
      requirements: m.requirements?.length ? m.requirements : titles.map((t) => `Apply the ideas from "${t}" in your project`),
      rubric: m.rubric?.length ? m.rubric : ['It runs without errors', 'I can explain each part in my own words', 'I used every module\'s key ideas'],
      conceptIds: conceptsOf(idx), xp: isCap ? 300 : 150,
    };
  });
  return { spineProject: raw.spineProject || `${course.title} project`, modules, milestones };
}

export async function designCurriculum(course: Course, a: Analysis, signal?: AbortSignal): Promise<Design> {
  let raw: RawDesign;
  if (hasKey() && a.concepts.length) {
    const list = a.concepts.map((c) => `${c.id} | ${c.name} | ${c.summary.slice(0, 140)} | ${c.quality}`).join('\n');
    try { raw = await askJson<RawDesign>(SYS, designPrompt(course.title, course.description, list, MILESTONE_EVERY), signal, 12000); }
    catch { raw = offlineDesign(course, a); }
  } else raw = offlineDesign(course, a);
  return normalizeDesign(raw, a, course);
}
