import type { Course, Curriculum, PipelineEvent, Step } from '../../shared/types';
import { hasKey, pool } from './client';
import { analyzeCourse } from './analyze';
import { designCurriculum } from './design';
import { generateModuleSteps } from './lesson';
import { addSteps, auditAndRepair } from './audit';

export async function forge(course: Course, emit: (e: PipelineEvent) => void, signal?: AbortSignal): Promise<Curriculum> {
  const mode = hasKey() ? 'claude' : 'offline';
  emit({ stage: 'parse', current: course.lectures.length, total: course.lectures.length,
    message: `Read ${course.lectures.length} lectures (${mode === 'claude' ? 'Claude' : 'offline heuristic'} mode)` });

  const analysis = await analyzeCourse(course, (done, total, title) =>
    emit({ stage: 'analyze', current: done, total, message: `Mapped concepts in “${title}”` }), signal);
  if (!analysis.concepts.length) throw new Error('No teachable content found in the lectures.');

  emit({ stage: 'design', current: 0, total: 1, message: `Designing project path for ${analysis.concepts.length} concepts…` });
  const design = await designCurriculum(course, analysis, signal);
  emit({ stage: 'design', current: 1, total: 1, message: `${design.modules.length} modules, ${design.milestones.length} milestone projects` });

  const drafts = await pool(design.modules, 3, async (m, i) => {
    const r = await generateModuleSteps(course, analysis, design, i, signal);
    emit({ stage: 'lessons', current: i + 1, total: design.modules.length, message: `Built lesson “${m.title}”` });
    return r;
  });
  const steps: Step[] = [];
  design.modules.forEach((m, i) => addSteps(steps, design, m.id, drafts[i]));

  emit({ stage: 'audit', current: 0, total: 1, message: 'Auditing coverage against the original course…' });
  const coverage = await auditAndRepair(course, analysis, design, steps, signal);
  emit({ stage: 'audit', current: 1, total: 1, message: `Coverage ${Math.round(coverage.score * 100)}% · ${coverage.fixed.length} concepts reinforced by AI` });

  const curriculum: Curriculum = {
    courseId: course.id, mode, spineProject: design.spineProject, modules: design.modules, milestones: design.milestones,
    steps, concepts: analysis.concepts, gaps: analysis.gaps, coverage, createdAt: Date.now(),
  };
  emit({ stage: 'done', current: 1, total: 1, message: 'Course forged', curriculum });
  return curriculum;
}
