import { STEP_XP, type Analysis, type Concept, type Course, type Quiz, type Step, type StepType } from '../../shared/types';
import { askJson, hasKey } from './client';
import { codeBlocks, offlineQuiz } from './offline';
import { fixPrompt, lessonPrompt, SYS } from './prompts';
import type { Design } from './design';

type RawStep = Partial<Omit<Step, 'id' | 'moduleId' | 'xp'>>;
export type StepDraft = Omit<Step, 'id' | 'moduleId' | 'xp'>;

const trimWords = (s: string, n: number) => { const w = s.split(/\s+/); return w.length > n ? w.slice(0, n).join(' ') + '…' : s; };

export function cleanStep(r: RawStep, validIds: Set<string>): StepDraft | null {
  if (!r.title || !r.type) return null;
  const type: StepType = (['explain', 'build', 'check', 'reflect'] as const).includes(r.type) ? r.type : 'explain';
  const quiz: Quiz | undefined = r.quiz && Array.isArray(r.quiz.options) && r.quiz.options.length >= 2
    ? { ...r.quiz, answer: Math.min(Math.max(0, r.quiz.answer | 0), r.quiz.options.length - 1) } : undefined;
  return {
    type: type === 'check' && !quiz ? 'explain' : type, title: r.title, body: r.body ?? '', code: r.code, language: r.language,
    task: r.task, hints: (r.hints ?? []).slice(0, 3), quiz, conceptIds: (r.conceptIds ?? []).filter((id) => validIds.has(id)),
    origin: r.origin === 'ai-fix' ? 'ai-fix' : 'course',
  };
}

/** Heuristic lesson for a group of concepts: explain -> build -> check per concept. */
export function offlineSteps(concepts: Concept[], all: Concept[], course: Course, projectSlice: string, origin: 'course' | 'ai-fix' = 'course'): StepDraft[] {
  const out: StepDraft[] = [];
  for (const c of concepts) {
    const lec = course.lectures.find((l) => l.id === c.lectureId);
    const code = lec ? codeBlocks(lec.text).find((b) => b.toLowerCase().includes(c.name.toLowerCase().split(' ')[0])) ?? codeBlocks(lec.text)[0] : undefined;
    const thin = c.quality !== 'solid';
    out.push({
      type: 'explain', title: c.name, origin: thin ? 'ai-fix' : origin, conceptIds: [c.id], hints: [],
      body: trimWords(c.summary, 110) + (thin ? `\n\n> **Reinforcement:** the course only touches this briefly. Original line: _"${c.sourceQuote}"_. Ask yourself: what problem does it solve, and when would it go wrong?` : ''),
    });
    out.push({
      type: 'build', title: `Build: ${c.name}`, origin, conceptIds: [c.id], language: code ? 'js' : undefined, code,
      task: code ? `Type the example below into your project, run it, then change one thing and predict the result.` : `Add something to your project (${projectSlice || 'your project'}) that uses "${c.name}". Write one sentence on what it does.`,
      body: `Put it to work right away.`, hints: [`Re-read the explanation above.`, `Start with the smallest version that could work.`, `Compare with the source line: "${c.sourceQuote.slice(0, 100)}"`],
    });
    out.push({ type: 'check', title: `Check: ${c.name}`, origin, conceptIds: [c.id], body: 'Quick recall.', hints: [], quiz: offlineQuiz(c, all) });
  }
  return out;
}

const reflect = (mod: { title: string; projectSlice: string }, ids: string[]): StepDraft => ({
  type: 'reflect', title: `Reflect: ${mod.title}`, origin: 'course', conceptIds: [], hints: [],
  body: `What did you build in this module${mod.projectSlice ? ` (${mod.projectSlice})` : ''}? What broke, and how did you fix it? Jot it down in your notes.`,
});

export async function generateModuleSteps(
  course: Course, a: Analysis, d: Design, mi: number, signal?: AbortSignal,
): Promise<StepDraft[]> {
  const mod = d.modules[mi];
  const cs = mod.conceptIds.map((id) => a.concepts.find((c) => c.id === id)!).filter(Boolean);
  const valid = new Set(a.concepts.map((c) => c.id));
  if (hasKey()) {
    const lecIds = new Set(cs.map((c) => c.lectureId));
    const sources = course.lectures.filter((l) => lecIds.has(l.id)).map((l) => `### ${l.title}\n${l.text.slice(0, 14000)}`).join('\n\n');
    const gaps = a.gaps.filter((g) => g.conceptId && mod.conceptIds.includes(g.conceptId) || (!g.conceptId && lecIds.has(g.lectureId)))
      .map((g) => `${g.kind}: ${g.note}`).join('\n');
    const list = cs.map((c) => `${c.id} | ${c.name} | ${c.summary.slice(0, 160)} | ${c.quality}`).join('\n');
    try {
      const r = await askJson<{ steps?: RawStep[] }>(SYS, lessonPrompt(d.spineProject, `${mod.title} — ${mod.projectSlice}`, list, gaps, sources), signal, 16000);
      const steps = (r.steps ?? []).map((s) => cleanStep(s, valid)).filter((s): s is StepDraft => !!s);
      if (steps.length) return steps.some((s) => s.type === 'reflect') ? steps : [...steps, reflect(mod, [])];
    } catch (e) { if (signal?.aborted) throw e; }
  }
  return [...offlineSteps(cs, a.concepts, course, mod.projectSlice), reflect(mod, [])];
}

export async function generateFixSteps(course: Course, a: Analysis, d: Design, missing: Concept[], signal?: AbortSignal): Promise<StepDraft[]> {
  const valid = new Set(a.concepts.map((c) => c.id));
  if (hasKey()) {
    const lecIds = new Set(missing.map((c) => c.lectureId));
    const sources = course.lectures.filter((l) => lecIds.has(l.id)).map((l) => `### ${l.title}\n${l.text.slice(0, 10000)}`).join('\n\n');
    const list = missing.map((c) => `${c.id} | ${c.name} | ${c.summary.slice(0, 160)}`).join('\n');
    try {
      const r = await askJson<{ steps?: RawStep[] }>(SYS, fixPrompt(d.spineProject, list, sources), signal, 12000);
      const steps = (r.steps ?? []).map((s) => cleanStep(s, valid)).filter((s): s is StepDraft => !!s);
      if (steps.length) return steps;
    } catch (e) { if (signal?.aborted) throw e; }
  }
  return offlineSteps(missing, a.concepts, course, '');
}

export const xpFor = (t: StepType) => STEP_XP[t];
