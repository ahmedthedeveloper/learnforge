import type { Analysis, Concept, Course, Gap, Lecture } from '../../shared/types';
import { askJson, hasKey, pool } from './client';
import { analyzePrompt, SYS } from './prompts';
import { offlineAnalyze } from './offline';

const CHUNK = 24000;
type Raw = ReturnType<typeof offlineAnalyze>;
type AiRaw = { concepts?: Partial<Concept>[]; gaps?: { kind?: Gap['kind']; note?: string; concept?: string }[] };

function chunks(text: string): string[] {
  if (text.length <= CHUNK) return [text];
  const out: string[] = [];
  for (let i = 0; i < text.length; i += CHUNK - 1500) out.push(text.slice(i, i + CHUNK));
  return out;
}

async function analyzeOne(course: Course, lec: Lecture, known: string[], signal?: AbortSignal): Promise<Raw & { names: Map<string, number> }> {
  const concepts: Raw['concepts'] = [];
  const gaps: (Raw['gaps'][number] & { concept?: string })[] = [];
  if (!hasKey()) {
    const r = offlineAnalyze(lec);
    return { ...r, names: new Map() };
  }
  for (const part of chunks(lec.text)) {
    const r = await askJson<AiRaw>(SYS, analyzePrompt(course.title, lec.title, part, known), signal);
    for (const c of r.concepts ?? []) {
      if (!c.name) continue;
      concepts.push({
        lectureId: lec.id, name: c.name, summary: c.summary ?? '', sourceQuote: c.sourceQuote ?? '',
        difficulty: Math.min(5, Math.max(1, Math.round(c.difficulty ?? 2))), quality: c.quality ?? 'solid',
      });
    }
    for (const g of r.gaps ?? []) gaps.push({ lectureId: lec.id, kind: g.kind ?? 'thin', note: g.note ?? '', concept: g.concept });
  }
  return { concepts, gaps, names: new Map() };
}

export async function analyzeCourse(
  course: Course, onProgress: (done: number, total: number, title: string) => void, signal?: AbortSignal,
): Promise<Analysis> {
  const ordered = [...course.lectures].sort((a, b) => a.order - b.order);
  let done = 0;
  const known: string[] = [];
  const results = await pool(ordered, 3, async (lec) => {
    const r = await analyzeOne(course, lec, known, signal);
    known.push(...r.concepts.map((c) => c.name));
    onProgress(++done, ordered.length, lec.title);
    return r;
  });

  const concepts: Concept[] = [];
  const gaps: Gap[] = [];
  const byName = new Map<string, Concept>();
  results.forEach((r) => {
    for (const c of r.concepts) {
      const key = c.name.toLowerCase().trim();
      const prev = byName.get(key);
      if (prev) { // merge duplicate: keep the best quality, extend summary
        if (c.summary && !prev.summary.includes(c.summary)) prev.summary += ' ' + c.summary;
        if (prev.quality !== 'solid' && c.quality === 'solid') prev.quality = 'solid';
        continue;
      }
      const full: Concept = { ...c, id: `c_${String(concepts.length + 1).padStart(3, '0')}` };
      concepts.push(full);
      byName.set(key, full);
    }
    for (const g of r.gaps as (Omit<Gap, 'id'> & { concept?: string })[]) {
      const cid = g.concept ? byName.get(g.concept.toLowerCase().trim())?.id : undefined;
      gaps.push({ id: `g_${String(gaps.length + 1).padStart(3, '0')}`, lectureId: g.lectureId, kind: g.kind, note: g.note, conceptId: cid });
    }
  });
  return { concepts, gaps };
}
