import Anthropic from '@anthropic-ai/sdk';
import { spawn } from 'node:child_process';
import os from 'node:os';

export const MODEL = process.env.LF_MODEL ?? 'claude-sonnet-5-5';
export const useClaudeCode = () => process.env.LF_PROVIDER === 'claude-code';
/** True when some AI backend is configured (API key or the local Claude Code login). */
export const hasKey = () => useClaudeCode() || !!process.env.ANTHROPIC_API_KEY;

/** One-shot call through the Claude Code CLI, which uses the user's own claude.ai login. */
function claudeCode(system: string, user: string, signal?: AbortSignal): Promise<string> {
  return new Promise((resolve, reject) => {
    const args = ['-p', '--no-session-persistence', '--output-format', 'text'];
    if (process.env.LF_CC_MODEL) args.push('--model', process.env.LF_CC_MODEL);
    const child = spawn('claude', args, { cwd: os.tmpdir(), shell: process.platform === 'win32', signal });
    let out = '', err = '';
    child.stdout.on('data', (d) => (out += d));
    child.stderr.on('data', (d) => (err += d));
    child.on('error', (e) => reject((e as NodeJS.ErrnoException).code === 'ENOENT'
      ? new Error('Claude Code is not installed. Run: npm install -g @anthropic-ai/claude-code, then run "claude" once to log in.') : e));
    child.on('close', (code) => (code === 0 && out.trim() ? resolve(out)
      : reject(new Error(`Claude Code failed (${code}): ${(err || out).trim().slice(0, 300) || 'is it logged in? run "claude" once'}`))));
    child.stdin.end(`${system}\n\n${user}`);
  });
}

let sdk: Anthropic | null = null;
const client = () => (sdk ??= new Anthropic());

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function extractJson(text: string): unknown {
  const s = text.replace(/```(?:json)?/g, '');
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('no JSON object in response');
  return JSON.parse(s.slice(a, b + 1));
}

/** Ask for a JSON object; retries on transient errors and on invalid JSON. */
export async function askJson<T>(system: string, user: string, signal?: AbortSignal, maxTokens = 8000): Promise<T> {
  let lastErr: unknown;
  let prompt = user;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (signal?.aborted) throw new Error('aborted');
    try {
      const text = useClaudeCode()
        ? await claudeCode(system, prompt, signal)
        : (await client().messages.create(
          { model: MODEL, max_tokens: maxTokens, system, messages: [{ role: 'user', content: prompt }] },
          { signal },
        )).content.map((b) => (b.type === 'text' ? b.text : '')).join('');
      try { return extractJson(text) as T; }
      catch (e) {
        lastErr = e;
        prompt = user + '\n\nYour previous output was not valid JSON. Reply with ONLY one valid JSON object.';
      }
    } catch (e) {
      lastErr = e;
      const status = (e as { status?: number }).status;
      if (signal?.aborted || (e instanceof Error && /not installed|Claude Code failed/.test(e.message) && attempt > 0)) throw e;
      if (status && status < 500 && status !== 429) throw e;
      await sleep(1000 * 2 ** attempt);
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('AI request failed');
}

/** Run tasks with a concurrency cap, preserving order. */
export async function pool<T, R>(items: T[], limit: number, fn: (x: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) { const i = next++; out[i] = await fn(items[i], i); }
  }));
  return out;
}
