import Anthropic from '@anthropic-ai/sdk';

export const MODEL = process.env.LF_MODEL ?? 'claude-sonnet-5-5';
export const hasKey = () => !!process.env.ANTHROPIC_API_KEY;

let sdk: Anthropic | null = null;
const client = () => (sdk ??= new Anthropic());

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export function extractJson(text: string): unknown {
  const s = text.replace(/```(?:json)?/g, '');
  const a = s.indexOf('{'), b = s.lastIndexOf('}');
  if (a < 0 || b < a) throw new Error('no JSON object in response');
  return JSON.parse(s.slice(a, b + 1));
}

/** Ask for a JSON object; retries on transient errors and on invalid JSON. */
export async function askJson<T>(system: string, user: string, signal?: AbortSignal, maxTokens = 8000): Promise<T> {
  let lastErr: unknown;
  let prompt = user;
  for (let attempt = 0; attempt < 3; attempt++) {
    if (signal?.aborted) throw new Error('aborted');
    try {
      const res = await client().messages.create(
        { model: MODEL, max_tokens: maxTokens, system, messages: [{ role: 'user', content: prompt }] },
        { signal },
      );
      const text = res.content.map((b) => (b.type === 'text' ? b.text : '')).join('');
      try { return extractJson(text) as T; }
      catch (e) {
        lastErr = e;
        prompt = user + '\n\nYour previous output was not valid JSON. Reply with ONLY one valid JSON object.';
      }
    } catch (e) {
      lastErr = e;
      const status = (e as { status?: number }).status;
      if (status && status < 500 && status !== 429) throw e;
      await sleep(1000 * 2 ** attempt);
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('AI request failed');
}

/** Run tasks with a concurrency cap, preserving order. */
export async function pool<T, R>(items: T[], limit: number, fn: (x: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) { const i = next++; out[i] = await fn(items[i], i); }
  }));
  return out;
}
