import type { Analysis, Concept, Gap, Lecture, Quiz } from '../../shared/types';

const sentences = (t: string) =>
  t.replace(/```[\s\S]*?```/g, ' ').split(/(?<=[.!?])\s+|\n+/).map((s) => s.trim()).filter((s) => s.length > 25);

const VISUAL = /\b(as you can see|on (the )?screen|right here|over here|this button|click (on )?(here|this))\b/i;
const THIN = /\b(we'?ll (cover|see|get to) [^.,]{0,30}later|briefly|just remember|don'?t worry about)\b/i;
const DEFN = /\b(is|are|means|refers to|allows|lets|returns|creates|used to|helps)\b/i;

export function codeBlocks(text: string): string[] {
  return [...text.matchAll(/```(?:\w+)?\n([\s\S]*?)```/g)].map((m) => m[1].trim());
}

function nameOf(s: string): string {
  const words = s.replace(/[`*_#>]/g, '').split(/\s+/);
  const cut = words.findIndex((w) => /^(is|are|means|refers|allows|lets|returns|creates|used|helps)$/i.test(w));
  const head = (cut > 0 ? words.slice(0, cut) : words.slice(0, 6)).join(' ').replace(/^(the|a|an)\s+/i, '');
  return head.slice(0, 60).replace(/[,:;]$/, '') || 'Idea';
}

/** Deterministic analyzer used when no API key is present (and in tests). */
export function offlineAnalyze(lec: Lecture): { concepts: Omit<Concept, 'id'>[]; gaps: Omit<Gap, 'id'>[] } {
  const sents = sentences(lec.text);
  const concepts: Omit<Concept, 'id'>[] = [];
  const gaps: Omit<Gap, 'id'>[] = [];
  const seen = new Set<string>();
  for (const s of sents) {
    const isHead = /^#{1,4}\s/.test(s) || /^[-*]\s/.test(s);
    if (!isHead && !DEFN.test(s) && !/`[^`]+`/.test(s)) continue;
    const name = nameOf(s);
    const key = name.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    const thin = THIN.test(s) || s.length < 45;
    concepts.push({
      lectureId: lec.id, name, summary: s.replace(/^[-*#\s]+/, ''), sourceQuote: s.slice(0, 160),
      difficulty: Math.min(5, 1 + Math.floor(s.length / 90)), quality: thin ? 'thin' : 'solid',
    });
    if (thin) gaps.push({ lectureId: lec.id, kind: 'thin', note: `"${name}" is mentioned but barely explained.` });
  }
  if (!concepts.length && sents[0]) {
    concepts.push({ lectureId: lec.id, name: lec.title, summary: sents[0], sourceQuote: sents[0].slice(0, 160), difficulty: 1, quality: 'thin' });
  }
  sents.filter((s) => VISUAL.test(s)).forEach((s) =>
    gaps.push({ lectureId: lec.id, kind: 'visual-only', note: `Relies on the screen: "${s.slice(0, 100)}"` }));
  return { concepts, gaps };
}

export function offlineQuiz(c: Concept, pool: Concept[]): Quiz {
  const words = c.summary.split(/\s+/);
  let idx = words.findIndex((w, i) => i > 1 && w.replace(/\W/g, '').length > 5);
  if (idx < 0) idx = Math.min(words.length - 1, 2);
  const answer = words[idx].replace(/[^\w-]/g, '') || words[idx];
  const distract = pool.flatMap((p) => p.summary.split(/\s+/)).map((w) => w.replace(/[^\w-]/g, ''))
    .filter((w) => w.length > 4 && w.toLowerCase() !== answer.toLowerCase());
  const opts = [answer, ...[...new Set(distract)].slice(0, 3)];
  while (opts.length < 3) opts.push(['pattern', 'default', 'handler'][opts.length]);
  const shown = words.map((w, i) => (i === idx ? '_____' : w)).join(' ');
  const order = opts.map((o, i) => ({ o, i })).sort((a, b) => ((a.i * 7 + c.name.length) % 5) - ((b.i * 7 + c.name.length) % 5));
  return {
    question: `Fill in the blank: "${shown}"`, options: order.map((x) => x.o),
    answer: order.findIndex((x) => x.i === 0), explanation: `From the course: "${c.summary}"`,
  };
}

export function offlineAnalysisSummary(a: Analysis) {
  return `${a.concepts.length} concepts, ${a.gaps.length} gaps`;
}
