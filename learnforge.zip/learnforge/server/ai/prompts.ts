export const SYS = `You are LearnForge, an expert instructor who converts course material into project-based, build-while-explaining lessons. Never drop information from the source. Ground everything in the supplied text. Reply with ONLY a JSON object.`;

export const analyzePrompt = (course: string, title: string, text: string, known: string[]) => `Course: ${course}
Lecture: ${title}
Already-known concepts from earlier lectures: ${known.slice(-60).join('; ') || 'none'}

Extract EVERY teachable item (definitions, syntax, commands, patterns, gotchas, tips, examples, analogies, best practices). Do not summarize away detail.
Return JSON: {"concepts":[{"name":str,"summary":str,"sourceQuote":str(shortest proving snippet),"difficulty":1-5,"quality":"solid"|"thin"|"missing-context"}],"gaps":[{"kind":"thin"|"visual-only"|"undefined-term"|"missing-prereq"|"error","note":str,"concept":str(name, optional)}]}
Use quality "thin" if only mentioned, not explained; "missing-context" if it relies on an undefined prerequisite. Add gaps for "as you can see on screen", undefined jargon, skipped steps, factual errors, outdated usage.

LECTURE TEXT:
${text}`;

export const designPrompt = (course: string, desc: string, concepts: string, every: number) => `Course: ${course}
${desc}
Concepts in source order (id | name | summary | quality):
${concepts}

Design a project-based curriculum:
- One continuous spine project (reuse the project the course builds if it has one) that exercises all concepts.
- Modules of 4-9 concepts, following source order unless prerequisites force otherwise. EVERY concept id must appear in exactly one module.
- Each module has a projectSlice: the feature added to the spine project.
- After every ${every} modules add a milestone project integrating those modules, plus a final capstone.
Return JSON: {"spineProject":str,"modules":[{"title":str,"goal":str,"projectSlice":str,"conceptIds":[str]}],"milestones":[{"title":str,"brief":str,"moduleIndexes":[int (0-based)],"requirements":[str],"rubric":[str]}]}`;

export const lessonPrompt = (spine: string, mod: string, concepts: string, gaps: string, sources: string) => `Spine project: ${spine}
Module: ${mod}
Concepts to cover (id | name | summary | quality):
${concepts}
Known gaps in the source to repair:
${gaps || 'none'}

Original lecture text for grounding:
${sources}

Write 6-14 steps using the loop EXPLAIN (<=120 words, one idea) -> BUILD (task, starter code, 1-3 progressive hints) -> CHECK (one multiple-choice question). Code is cumulative across steps. Reuse the source's terminology and examples. For every concept with quality thin/missing-context or listed gap, add an extra explain/build step with origin "ai-fix" that explains it properly (what, why, example, pitfall). Finish with one "reflect" step. Every concept id above must appear in some step's conceptIds, including in a build or check step.
Return JSON: {"steps":[{"type":"explain"|"build"|"check"|"reflect","title":str,"body":str(markdown),"code":str?,"language":str?,"task":str?,"hints":[str],"quiz":{"question":str,"options":[str],"answer":int,"explanation":str}?,"conceptIds":[str],"origin":"course"|"ai-fix"}]}`;

export const fixPrompt = (spine: string, concepts: string, sources: string) => `Spine project: ${spine}
These concepts from the source course are NOT yet taught well. Write steps (explain -> build -> check, same JSON format as before) that teach each one by building, grounded in the text.
Concepts (id | name | summary):
${concepts}
Source text:
${sources}
Return JSON: {"steps":[...same step schema, origin "course"...]}`;
