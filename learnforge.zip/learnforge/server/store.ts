import fs from 'node:fs';
import path from 'node:path';
import type { Course, Curriculum } from '../shared/types';

const DIR = path.resolve(process.env.LF_DATA ?? path.join(import.meta.dirname, 'data'));
fs.mkdirSync(DIR, { recursive: true });

function file(kind: string, id: string) {
  if (!/^[\w-]+$/.test(id)) throw new Error('bad id');
  return path.join(DIR, `${kind}_${id}.json`);
}
function write(p: string, data: unknown) {
  const tmp = p + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data));
  fs.renameSync(tmp, p);
}
function read<T>(p: string): T | null {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')) as T; } catch { return null; }
}

export const saveCourse = (c: Course) => write(file('course', c.id), c);
export const getCourse = (id: string) => read<Course>(file('course', id));
export const deleteCourse = (id: string) => {
  for (const k of ['course', 'curriculum']) fs.rmSync(file(k, id), { force: true });
};
export const listCourses = (): Course[] =>
  fs.readdirSync(DIR).filter((f) => f.startsWith('course_') && f.endsWith('.json'))
    .map((f) => read<Course>(path.join(DIR, f))).filter((c): c is Course => !!c)
    .sort((a, b) => b.createdAt - a.createdAt);
export const saveCurriculum = (c: Curriculum) => write(file('curriculum', c.courseId), c);
export const getCurriculum = (id: string) => read<Curriculum>(file('curriculum', id));
