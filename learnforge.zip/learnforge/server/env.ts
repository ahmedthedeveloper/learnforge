import fs from 'node:fs';
import path from 'node:path';

// Load .env from the project root (Node 21.7+). Real environment variables win.
const file = path.resolve(import.meta.dirname, '../.env');
if (fs.existsSync(file)) process.loadEnvFile(file);
