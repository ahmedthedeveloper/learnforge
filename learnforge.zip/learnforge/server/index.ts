import './env';
import express from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import { hasKey, MODEL } from './ai/client';
import { forge } from './ai/pipeline';
import { buildCourse, lecturesFromFiles, lecturesFromPaste, uid } from './ingest/structure';
import { deleteCourse, getCourse, getCurriculum, listCourses, saveCourse, saveCurriculum } from './store';
import type { Course, Lecture, PipelineEvent } from '../shared/types';

const app = express();
app.use(express.json({ limit: '30mb' }));
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4_000_000, files: 500 } });

app.get('/api/health', (_req, res) => res.json({ ok: true, aiMode: hasKey() ? 'claude' : 'offline', model: MODEL }));

app.get('/api/courses', (_req, res) => {
  res.json(listCourses().map((c) => ({ ...c, lectures: c.lectures.map((l) => ({ ...l, text: '' })), forged: !!getCurriculum(c.id) })));
});

app.post('/api/ingest', upload.array('files'), (req, res) => {
  const files = ((req.files as Express.Multer.File[]) ?? []).map((f) => ({ name: f.originalname, content: f.buffer.toString('utf8') }));
  if (!files.length) return res.status(400).json({ error: 'No files uploaded' });
  res.json(lecturesFromFiles(files));
});

app.post('/api/paste', (req, res) => {
  const text = String(req.body?.text ?? '');
  if (text.trim().length < 20) return res.status(400).json({ error: 'Paste some course text first' });
  res.json(lecturesFromPaste(text));
});

app.post('/api/courses', (req, res) => {
  const { title, description = '', sections = [], lectures = [] } = req.body ?? {};
  const clean: Lecture[] = (lectures as Lecture[]).filter((l) => l.text?.trim()).map((l, i) => ({ ...l, id: l.id || uid('l'), order: i }));
  if (!title || !clean.length) return res.status(400).json({ error: 'A title and at least one non-empty lecture are required' });
  const course = buildCourse(String(title), String(description), { sections, lectures: clean });
  saveCourse(course);
  res.json(course);
});

app.get('/api/courses/:id', (req, res) => {
  const c = getCourse(req.params.id);
  c ? res.json(c) : res.status(404).json({ error: 'Course not found' });
});
app.delete('/api/courses/:id', (req, res) => { deleteCourse(req.params.id); res.json({ ok: true }); });

app.get('/api/courses/:id/curriculum', (req, res) => {
  const c = getCurriculum(req.params.id);
  c ? res.json(c) : res.status(404).json({ error: 'Not forged yet' });
});

app.post('/api/courses/:id/forge', async (req, res) => {
  const course: Course | null = getCourse(req.params.id);
  if (!course) return res.status(404).json({ error: 'Course not found' });
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  res.flushHeaders();
  const ac = new AbortController();
  res.on('close', () => ac.abort());
  const send = (e: PipelineEvent) => res.write(`data: ${JSON.stringify(e)}\n\n`);
  try {
    const cur = await forge(course, send, ac.signal);
    saveCurriculum(cur);
  } catch (e) {
    if (!ac.signal.aborted) send({ stage: 'error', current: 0, total: 0, message: e instanceof Error ? e.message : 'Failed' });
  }
  res.end();
});

const dist = path.resolve(import.meta.dirname, '../dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('/{*splat}', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

const port = Number(process.env.PORT ?? 8787);
app.listen(port, () => console.log(`LearnForge API on :${port} (${hasKey() ? 'Claude' : 'offline'} mode)`));
