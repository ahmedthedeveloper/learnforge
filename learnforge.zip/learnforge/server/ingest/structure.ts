import { randomUUID } from 'node:crypto';
import type { Course, Lecture, Section } from '../../shared/types';
import { parseByName, parseText } from './parse';

export const uid = (p: string) => `${p}_${randomUUID().slice(0, 8)}`;
export const naturalSort = (a: string, b: string) => a.localeCompare(b, undefined, { numeric: true });

const prettify = (name: string) =>
  name.replace(/\.[^.]+$/, '').replace(/^[\d._\-\s]+|^S\d+_?L\d+[_\-\s]*/i, '').replace(/[_-]+/g, ' ').trim() || name;

/** "S02_L05 - Title.vtt" / "02-03 title" / "05 title" -> section number */
function sectionKey(name: string): string {
  const m = name.match(/^S(\d+)[_\-\s]?L\d+/i) ?? name.match(/^(\d+)[._\-](\d+)/);
  return m ? m[1] : 'all';
}

export interface RawFile { name: string; content: string }

export function lecturesFromFiles(files: RawFile[]): { sections: Section[]; lectures: Lecture[] } {
  const sorted = [...files].sort((a, b) => naturalSort(a.name, b.name));
  const sections = new Map<string, Section>();
  const lectures: Lecture[] = [];
  sorted.forEach((f, i) => {
    const key = sectionKey(f.name);
    if (!sections.has(key)) {
      sections.set(key, { id: uid('s'), title: key === 'all' ? 'Course' : `Section ${+key}`, order: sections.size });
    }
    const { kind, text } = parseByName(f.name, f.content);
    if (!text) return;
    lectures.push({ id: uid('l'), sectionId: sections.get(key)!.id, title: prettify(f.name), kind, text, order: i });
  });
  return { sections: [...sections.values()], lectures };
}

/** Pasted text: "# Section" and "## Lecture" markers; plain text becomes one lecture. */
export function lecturesFromPaste(raw: string): { sections: Section[]; lectures: Lecture[] } {
  const sections: Section[] = [];
  const lectures: Lecture[] = [];
  let sec: Section | null = null;
  let cur: { title: string; lines: string[] } | null = null;
  const flush = () => {
    if (cur && sec) {
      const text = parseText(cur.lines.join('\n'));
      if (text) lectures.push({ id: uid('l'), sectionId: sec.id, title: cur.title, kind: 'article', text, order: lectures.length });
    }
    cur = null;
  };
  const ensureSec = (title = 'Course') => { sec = { id: uid('s'), title, order: sections.length }; sections.push(sec); };
  for (const line of raw.replace(/\r/g, '').split('\n')) {
    const h1 = line.match(/^#\s+(.+)/), h2 = line.match(/^##\s+(.+)/);
    if (h1) { flush(); ensureSec(h1[1].trim()); }
    else if (h2) { flush(); if (!sec) ensureSec(); cur = { title: h2[1].trim(), lines: [] }; }
    else { if (!sec) ensureSec(); if (!cur) cur = { title: 'Lecture 1', lines: [] }; cur.lines.push(line); }
  }
  flush();
  return { sections, lectures };
}

export function buildCourse(title: string, description: string, s: { sections: Section[]; lectures: Lecture[] }): Course {
  return { id: uid('c'), title, description, sections: s.sections, lectures: s.lectures, createdAt: Date.now() };
}
