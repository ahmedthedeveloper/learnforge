const TS = /^\s*(\d+:)?\d{1,2}:\d{2}[.,]\d{3}\s*-->/;

function dedupeLines(lines: string[]): string[] {
  const out: string[] = [];
  for (const l of lines) if (out[out.length - 1] !== l) out.push(l);
  return out;
}

/** Strip captions metadata and merge cue fragments into flowing prose. */
export function parseCaptions(raw: string): string {
  const lines: string[] = [];
  let inNote = false;
  for (const line of raw.replace(/\r/g, '').split('\n')) {
    const t = line.trim();
    if (/^WEBVTT/.test(t) || /^(Kind|Language):/.test(t)) continue;
    if (/^(NOTE|STYLE|REGION)\b/.test(t)) { inNote = true; continue; }
    if (!t) { inNote = false; continue; }
    if (inNote || TS.test(t) || /^\d+$/.test(t)) continue;
    lines.push(t.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&'));
  }
  const text = dedupeLines(lines).join(' ').replace(/(\w)- (\w)/g, '$1$2').replace(/\s+/g, ' ').trim();
  return text.replace(/([.!?])\s+(?=[A-Z])/g, '$1\n').replace(/\n/g, ' ').trim();
}

export function parseHtml(raw: string): string {
  let s = raw.replace(/<(script|style)[\s\S]*?<\/\1>/gi, '');
  s = s.replace(/<pre[^>]*>([\s\S]*?)<\/pre>/gi, (_, c) => '\n```\n' + c.replace(/<[^>]+>/g, '') + '\n```\n');
  s = s.replace(/<h([1-6])[^>]*>([\s\S]*?)<\/h\1>/gi, (_, n, c) => `\n${'#'.repeat(+n)} ${c.replace(/<[^>]+>/g, '')}\n`);
  s = s.replace(/<li[^>]*>/gi, '\n- ').replace(/<\/(p|div|br|tr)>|<br\s*\/?>/gi, '\n');
  s = s.replace(/<[^>]+>/g, '');
  return decodeEntities(s).replace(/\n{3,}/g, '\n\n').trim();
}

function decodeEntities(s: string) {
  return s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'").replace(/&amp;/g, '&');
}

export function parseText(raw: string): string {
  return raw.replace(/\r/g, '').replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}

export function parseByName(name: string, raw: string): { kind: 'video' | 'article'; text: string } {
  const ext = name.toLowerCase().split('.').pop() ?? '';
  if (ext === 'vtt' || ext === 'srt') return { kind: 'video', text: parseCaptions(raw) };
  if (ext === 'html' || ext === 'htm') return { kind: 'article', text: parseHtml(raw) };
  return { kind: 'article', text: parseText(raw) };
}
