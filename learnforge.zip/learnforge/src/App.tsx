import { useEffect, useState } from 'react';
import { api } from './api';
import { useStore } from './store/useStore';
import { setReducedMotion } from './lib/gsapSetup';
import { Shell } from './components/Shell';
import { Dashboard } from './components/Dashboard';
import { Importer } from './components/Importer';
import { PipelineView } from './components/PipelineView';
import { CoursePath } from './components/CoursePath';
import { LessonPlayer } from './components/LessonPlayer';
import { MilestoneProject } from './components/MilestoneProject';

export default function App() {
  const route = useStore((s) => s.route), theme = useStore((s) => s.theme), rm = useStore((s) => s.reducedMotion);
  const [mode, setMode] = useState<string>();
  useEffect(() => { document.documentElement.dataset.theme = theme; }, [theme]);
  useEffect(() => { setReducedMotion(rm); }, [rm]);
  useEffect(() => { api.health().then((h) => setMode(h.aiMode)).catch(() => {}); }, []);
  return (
    <Shell mode={mode}>
      {route.name === 'dashboard' && <Dashboard />}
      {route.name === 'import' && <Importer />}
      {route.name === 'forge' && <PipelineView key={route.courseId} courseId={route.courseId} />}
      {route.name === 'path' && <CoursePath key={route.courseId} courseId={route.courseId} tab={route.tab} />}
      {route.name === 'lesson' && <LessonPlayer key={route.moduleId} courseId={route.courseId} moduleId={route.moduleId} idx={route.idx} />}
      {route.name === 'milestone' && <MilestoneProject key={route.msId} courseId={route.courseId} msId={route.msId} />}
    </Shell>
  );
}
