import { Fragment, type ReactNode } from 'react';

function inline(s: string): ReactNode[] {
  return s.split(/(`[^`]+`|\*\*[^*]+\*\*|_[^_]+_)/g).map((p, i) =>
    p.startsWith('`') ? <code key={i}>{p.slice(1, -1)}</code>
      : p.startsWith('**') ? <strong key={i}>{p.slice(2, -2)}</strong>
      : p.startsWith('_') && p.endsWith('_') && p.length > 2 ? <em key={i}>{p.slice(1, -1)}</em> : <Fragment key={i}>{p}</Fragment>);
}

/** Small safe markdown subset: paragraphs, lists, blockquotes, inline code/bold/italic, fences. */
export function Md({ text }: { text: string }) {
  const out: ReactNode[] = [];
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    if (l.startsWith('```')) {
      const buf: string[] = [];
      for (i++; i < lines.length && !lines[i].startsWith('```'); i++) buf.push(lines[i]);
      out.push(<div className="code" key={i}><pre>{buf.join('\n')}</pre></div>);
    } else if (/^>\s?/.test(l)) {
      out.push(<blockquote key={i}>{inline(l.replace(/^>\s?/, ''))}</blockquote>);
    } else if (/^[-*]\s/.test(l)) {
      const items: string[] = [];
      for (; i < lines.length && /^[-*]\s/.test(lines[i]); i++) items.push(lines[i].slice(2));
      i--; out.push(<ul key={i}>{items.map((x, k) => <li key={k}>{inline(x)}</li>)}</ul>);
    } else if (l.trim()) out.push(<p key={i}>{inline(l)}</p>);
  }
  return <div className="md">{out}</div>;
}
