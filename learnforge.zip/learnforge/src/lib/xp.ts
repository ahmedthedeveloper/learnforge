export const levelOf = (xp: number) => Math.floor(Math.sqrt(xp / 50)) + 1;
export const levelFloor = (lvl: number) => 50 * (lvl - 1) ** 2;
export const levelProgress = (xp: number) => {
  const l = levelOf(xp), a = levelFloor(l), b = levelFloor(l + 1);
  return { level: l, pct: (xp - a) / (b - a), into: xp - a, need: b - a };
};
export const dayKey = (d = new Date()) => d.toISOString().slice(0, 10);
export const daysBetween = (a: string, b: string) => Math.round((Date.parse(b) - Date.parse(a)) / 86400000);
