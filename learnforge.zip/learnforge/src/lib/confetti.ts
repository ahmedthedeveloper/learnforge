import { gsap, reduced } from './gsapSetup';

const COLORS = ['#7c5cff', '#22d3ee', '#ffb547', '#ff4fa3', '#34d399'];

/** Canvas confetti driven by the GSAP ticker. */
export function fireConfetti(count = 140) {
  if (reduced()) return;
  const cv = document.createElement('canvas');
  cv.className = 'confetti';
  cv.width = innerWidth; cv.height = innerHeight;
  document.body.appendChild(cv);
  const ctx = cv.getContext('2d')!;
  const ps = Array.from({ length: count }, () => ({
    x: cv.width / 2, y: cv.height * 0.6, vx: (Math.random() - 0.5) * 18, vy: -Math.random() * 18 - 6,
    r: Math.random() * Math.PI, vr: (Math.random() - 0.5) * 0.4, w: 6 + Math.random() * 6, c: COLORS[(Math.random() * COLORS.length) | 0],
  }));
  let t = 0;
  const tick = () => {
    t += gsap.ticker.deltaRatio();
    ctx.clearRect(0, 0, cv.width, cv.height);
    for (const p of ps) {
      p.vy += 0.45; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.r += p.vr;
      ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.r);
      ctx.fillStyle = p.c; ctx.globalAlpha = Math.max(0, 1 - t / 120); ctx.fillRect(-p.w / 2, -p.w / 4, p.w, p.w / 2); ctx.restore();
    }
    if (t > 120) { gsap.ticker.remove(tick); cv.remove(); }
  };
  gsap.ticker.add(tick);
}
