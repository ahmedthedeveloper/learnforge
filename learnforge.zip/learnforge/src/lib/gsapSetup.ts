import { useLayoutEffect, type DependencyList, type RefObject } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Flip } from 'gsap/Flip';
import { TextPlugin } from 'gsap/TextPlugin';

gsap.registerPlugin(ScrollTrigger, Flip, TextPlugin);

let userReduced = false;
export const setReducedMotion = (v: boolean) => { userReduced = v; };
export const reduced = () =>
  userReduced || (typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches);

/** Scoped GSAP context; animations are skipped (elements stay visible) when motion is reduced. */
export function useGsap(scope: RefObject<Element | null>, fn: () => void, deps: DependencyList = []) {
  useLayoutEffect(() => {
    if (reduced()) return;
    const ctx = gsap.context(fn, scope.current ?? undefined);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
}

export function reveal(targets: gsap.TweenTarget, vars: gsap.TweenVars = {}) {
  if (reduced()) return;
  gsap.from(targets, { autoAlpha: 0, y: 24, duration: 0.7, ease: 'power3.out', stagger: 0.07, clearProps: 'transform,opacity,visibility', ...vars });
}

export function countUp(el: HTMLElement | null, to: number, suffix = '', duration = 1.1) {
  if (!el) return;
  if (reduced()) { el.textContent = Math.round(to) + suffix; return; }
  const o = { v: parseFloat(el.dataset.v ?? '0') || 0 };
  gsap.to(o, { v: to, duration, ease: 'power2.out', onUpdate: () => { el.textContent = Math.round(o.v) + suffix; el.dataset.v = String(o.v); } });
}

/** Cards that tilt toward the cursor and buttons that lean toward it. */
export function tilt(el: HTMLElement) {
  if (reduced()) return () => {};
  const rx = gsap.quickTo(el, 'rotationX', { duration: 0.4, ease: 'power3' });
  const ry = gsap.quickTo(el, 'rotationY', { duration: 0.4, ease: 'power3' });
  gsap.set(el, { transformPerspective: 800 });
  const move = (e: PointerEvent) => {
    const r = el.getBoundingClientRect();
    ry(((e.clientX - r.left) / r.width - 0.5) * 8);
    rx(-((e.clientY - r.top) / r.height - 0.5) * 8);
  };
  const leave = () => { rx(0); ry(0); };
  el.addEventListener('pointermove', move); el.addEventListener('pointerleave', leave);
  return () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerleave', leave); };
}

export function magnetic(el: HTMLElement) {
  if (reduced()) return () => {};
  const x = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power3' });
  const y = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power3' });
  const move = (e: PointerEvent) => {
    const r = el.getBoundingClientRect();
    x((e.clientX - (r.left + r.width / 2)) * 0.18); y((e.clientY - (r.top + r.height / 2)) * 0.25);
  };
  const leave = () => { x(0); y(0); };
  el.addEventListener('pointermove', move); el.addEventListener('pointerleave', leave);
  return () => { el.removeEventListener('pointermove', move); el.removeEventListener('pointerleave', leave); };
}

export { gsap, ScrollTrigger, Flip };
