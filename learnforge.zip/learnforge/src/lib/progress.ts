import type { Curriculum } from '../../shared/types';
import type { CourseProgress } from '../store/useStore';

export const moduleDone = (cur: Curriculum, p: CourseProgress, moduleId: string) =>
  cur.modules.find((m) => m.id === moduleId)!.stepIds.every((id) => p.done[id]);

export const moduleProgress = (cur: Curriculum, p: CourseProgress, moduleId: string) => {
  const ids = cur.modules.find((m) => m.id === moduleId)!.stepIds;
  return ids.length ? ids.filter((id) => p.done[id]).length / ids.length : 1;
};

export function milestoneUnlocked(cur: Curriculum, p: CourseProgress, msId: string) {
  return cur.milestones.find((m) => m.id === msId)!.moduleIds.every((id) => moduleDone(cur, p, id));
}

/** A module opens when the previous module is done and any milestone that closes before it has been submitted. */
export function moduleUnlocked(cur: Curriculum, p: CourseProgress, idx: number) {
  if (idx === 0) return true;
  const prev = cur.modules[idx - 1];
  if (!moduleDone(cur, p, prev.id)) return false;
  const gate = cur.milestones.find((m) => m.afterModuleId === prev.id);
  return !gate || !!p.milestones[gate.id]?.done;
}

export function courseProgress(cur: Curriculum, p: CourseProgress) {
  const total = cur.steps.length + cur.milestones.length;
  const done = cur.steps.filter((s) => p.done[s.id]).length + cur.milestones.filter((m) => p.milestones[m.id]?.done).length;
  return total ? done / total : 0;
}

/** First place the learner should pick up from. */
export function resumeTarget(cur: Curriculum, p: CourseProgress) {
  for (let i = 0; i < cur.modules.length; i++) {
    const m = cur.modules[i];
    if (!moduleUnlocked(cur, p, i)) {
      const gate = cur.milestones.find((x) => x.afterModuleId === cur.modules[i - 1].id);
      if (gate) return { kind: 'milestone' as const, id: gate.id };
      break;
    }
    const idx = m.stepIds.findIndex((id) => !p.done[id]);
    if (idx >= 0) return { kind: 'lesson' as const, moduleId: m.id, idx };
  }
  const open = cur.milestones.find((m) => !p.milestones[m.id]?.done && milestoneUnlocked(cur, p, m.id));
  return open ? { kind: 'milestone' as const, id: open.id } : null;
}
