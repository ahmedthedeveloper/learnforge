import { useEffect, useRef, useState } from 'react';
import { api, type CourseSummary } from '../api';
import { useStore, BADGES, emptyProgress } from '../store/useStore';
import { courseProgress } from '../lib/progress';
import { levelOf } from '../lib/xp';
import { countUp, reveal, tilt, useGsap } from '../lib/gsapSetup';
import { ProgressRing } from './ProgressRing';
import { MagneticButton } from './Shell';

function CourseCard({ c, onChanged }: { c: CourseSummary; onChanged: () => void }) {
  const go = useStore((s) => s.go), cur = useStore((s) => s.curricula[c.id]), p = useStore((s) => s.progress[c.id]);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => (ref.current ? tilt(ref.current) : undefined), []);
  const pct = cur ? courseProgress(cur, p ?? emptyProgress()) : 0;
  return (
    <div className="glass course" ref={ref} role="button" tabIndex={0}
      onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.click()}
      onClick={() => go(c.forged ? { name: 'path', courseId: c.id } : { name: 'forge', courseId: c.id })}>
      <div className="row">
        <ProgressRing value={pct} />
        <div style={{ minWidth: 0 }}><h3 style={{ margin: 0 }}>{c.title}</h3><span className="muted">{c.lectures.length} lectures</span></div>
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <span className={`pill ${c.forged ? 'good' : 'warn'}`}>{c.forged ? 'Ready to play' : 'Not forged yet'}</span>
        <div className="spacer" />
        <button className="btn sm ghost" aria-label={`Delete ${c.title}`}
          onClick={async (e) => { e.stopPropagation(); if (confirm(`Delete "${c.title}"?`)) { await api.remove(c.id); useStore.getState().resetCourse(c.id); onChanged(); } }}>🗑</button>
      </div>
    </div>
  );
}

export function Dashboard() {
  const { go, xp, streak, badges, progress, curricula, setCurriculum, reducedMotion, setReducedMotion, resetAll } = useStore();
  const [courses, setCourses] = useState<CourseSummary[] | null>(null);
  const root = useRef<HTMLDivElement>(null);
  const stat = useRef<HTMLSpanElement[]>([]);
  const load = () => api.courses().then(setCourses).catch(() => setCourses([]));
  useEffect(() => { load(); }, []);
  useEffect(() => {
    courses?.filter((c) => c.forged && !curricula[c.id]).forEach((c) => api.curriculum(c.id).then(setCurriculum).catch(() => {}));
  }, [courses, curricula, setCurriculum]);

  const stepsDone = Object.values(progress).reduce((n, p) => n + Object.keys(p.done).length, 0);
  const stats: [string, number][] = [['Level', levelOf(xp)], ['Total XP', xp], ['Day streak', streak], ['Steps built', stepsDone]];
  const sig = stats.map(([, v]) => v).join();
  useEffect(() => { stats.forEach(([, v], i) => countUp(stat.current[i], v)); }, [sig]); // eslint-disable-line react-hooks/exhaustive-deps
  useGsap(root, () => { reveal('.hero > *'); reveal('.stat', { delay: 0.2 }); }, []);
  useEffect(() => { if (courses) reveal('.course', { delay: 0.1 }); }, [courses]);

  return (
    <div ref={root}>
      <section className="hero">
        <h1>Turn any course into <span className="grad">something you build</span></h1>
        <p className="muted">Feed LearnForge your lecture transcripts and articles. It rebuilds them as hands-on projects, explains while you build, patches weak spots, and tracks every milestone.</p>
        <MagneticButton className="btn primary" onClick={() => go({ name: 'import' })}>＋ Forge a new course</MagneticButton>
      </section>
      <div className="stats">
        {stats.map(([k], i) => (
          <div className="glass stat" key={k}><div className="v num"><span ref={(el) => { if (el) stat.current[i] = el; }}>0</span></div><div className="k">{k}</div></div>
        ))}
      </div>
      {badges.length > 0 && <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 24 }}>
        {badges.map((b) => <span className="pill" key={b}>{BADGES[b].icon} {BADGES[b].label}</span>)}</div>}
      <h2>Your courses</h2>
      {courses && courses.length === 0 && (
        <div className="glass empty"><div className="big">📚</div><h3>No courses yet</h3>
          <p className="muted">Upload caption files (.vtt/.srt) and articles, or paste course text.</p></div>
      )}
      <div className="grid">{courses?.map((c) => <CourseCard key={c.id} c={c} onChanged={load} />)}</div>
      <div className="glass card" style={{ marginTop: 32, display: 'flex', gap: 16, alignItems: 'center', flexWrap: 'wrap' }}>
        <b>Settings</b>
        <label className="check" style={{ margin: 0 }}><input type="checkbox" checked={reducedMotion} onChange={(e) => setReducedMotion(e.target.checked)} />Reduce motion</label>
        <div className="spacer" />
        <button className="btn sm ghost" onClick={() => confirm('Reset all XP and progress?') && resetAll()}>Reset progress</button>
      </div>
    </div>
  );
}
