import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useStore } from '../store/useStore';
import { countUp, gsap, reduced, reveal, useGsap } from '../lib/gsapSetup';
import { fireConfetti } from '../lib/confetti';
import type { PipelineEvent } from '../../shared/types';

const STAGES = [
  { id: 'parse', label: 'Read', icon: '📖' }, { id: 'analyze', label: 'Map concepts', icon: '🧭' },
  { id: 'design', label: 'Design projects', icon: '🏗' }, { id: 'lessons', label: 'Write lessons', icon: '✍️' },
  { id: 'audit', label: 'Audit & fix', icon: '🔍' },
] as const;

export function PipelineView({ courseId }: { courseId: string }) {
  const { go, setCurriculum } = useStore();
  const [prog, setProg] = useState<Record<string, [number, number]>>({});
  const [active, setActive] = useState('parse'), [log, setLog] = useState<string[]>([]), [err, setErr] = useState('');
  const [cov, setCov] = useState(0);
  const root = useRef<HTMLDivElement>(null), logEl = useRef<HTMLDivElement>(null), covEl = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useGsap(root, () => reveal('.stage, .glass'), []);

  useEffect(() => {
    if (started.current) return; started.current = true;
    const ac = new AbortController();
    api.forge(courseId, (e: PipelineEvent) => {
      if (e.stage === 'error') { setErr(e.message); return; }
      if (e.stage === 'done' && e.curriculum) {
        setCurriculum(e.curriculum); setCov(e.curriculum.coverage.score); fireConfetti();
        setTimeout(() => go({ name: 'path', courseId }), reduced() ? 600 : 2200);
      }
      setActive(e.stage);
      setProg((p) => ({ ...p, [e.stage]: [e.current, e.total] }));
      setLog((l) => [...l, e.message]);
    }, ac.signal).catch((e) => !ac.signal.aborted && setErr(e.message));
    return () => { /* keep running if StrictMode remounts */ };
  }, [courseId, go, setCurriculum]);

  useEffect(() => {
    const last = logEl.current?.lastElementChild;
    if (logEl.current) logEl.current.scrollTop = logEl.current.scrollHeight;
    if (last && !reduced()) gsap.from(last, { x: -16, autoAlpha: 0, duration: 0.35 });
  }, [log.length]);
  useEffect(() => { countUp(covEl.current, cov * 100, '%'); }, [cov]);
  useEffect(() => {
    if (reduced()) return;
    const t = gsap.to('.stage.on', { scale: 1.03, yoyo: true, repeat: -1, duration: 0.8, ease: 'sine.inOut' });
    return () => { t.kill(); gsap.set('.stage', { scale: 1 }); };
  }, [active]);

  const idx = STAGES.findIndex((s) => s.id === active);
  return (
    <div ref={root}>
      <section className="hero"><h1>Forging your <span className="grad">course</span>…</h1>
        <p className="muted">Mapping every concept, designing projects, writing build-along lessons, then auditing for anything missed.</p></section>
      <div className="stages">
        {STAGES.map((s, i) => {
          const [c, t] = prog[s.id] ?? [0, 1];
          const done = i < idx || (active === 'done');
          return (
            <div key={s.id} className={`stage ${i === idx ? 'on' : ''} ${done ? 'done' : ''}`}>
              <div style={{ fontSize: '1.4rem' }}>{done ? '✅' : s.icon}</div><b>{s.label}</b>
              <div className="bar"><i style={{ width: `${Math.min(100, (c / t) * 100)}%`, transition: 'width .4s' }} /></div>
            </div>
          );
        })}
      </div>
      <div className="cols">
        <div className="glass log" ref={logEl} aria-live="polite">{log.map((l, i) => <div key={i}>› {l}</div>)}{!log.length && <div>Starting…</div>}</div>
        <div className="glass card" style={{ textAlign: 'center' }}>
          <div className="muted">Source coverage</div><div style={{ fontSize: '4rem', fontWeight: 800 }} className="grad num"><span ref={covEl}>0%</span></div>
          {err && <><p role="alert" style={{ color: 'var(--bad)' }}>{err}</p><button className="btn" onClick={() => go({ name: 'dashboard' })}>Back</button></>}
        </div>
      </div>
    </div>
  );
}
