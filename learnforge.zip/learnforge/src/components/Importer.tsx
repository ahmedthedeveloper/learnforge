import { useRef, useState } from 'react';
import { api, type Structure } from '../api';
import { useStore } from '../store/useStore';
import { reveal, useGsap } from '../lib/gsapSetup';
import type { LectureKind } from '../../shared/types';

export function Importer() {
  const go = useStore((s) => s.go);
  const [title, setTitle] = useState(''), [desc, setDesc] = useState(''), [paste, setPaste] = useState('');
  const [s, setS] = useState<Structure>({ sections: [], lectures: [] });
  const [over, setOver] = useState(false), [busy, setBusy] = useState(false), [err, setErr] = useState('');
  const root = useRef<HTMLDivElement>(null), input = useRef<HTMLInputElement>(null);
  useGsap(root, () => reveal('.glass'), []);

  const merge = (n: Structure) => setS((o) => ({
    sections: [...o.sections, ...n.sections],
    lectures: [...o.lectures, ...n.lectures].map((l, i) => ({ ...l, order: i })),
  }));
  const guard = async (fn: () => Promise<void>) => { setErr(''); setBusy(true); try { await fn(); } catch (e) { setErr((e as Error).message); } setBusy(false); };
  const addFiles = (files: FileList | File[]) => guard(async () => merge(await api.ingest([...files])));
  const addPaste = () => guard(async () => { merge(await api.paste(paste)); setPaste(''); });
  const patch = (id: string, p: Partial<{ title: string; kind: LectureKind }>) =>
    setS((o) => ({ ...o, lectures: o.lectures.map((l) => (l.id === id ? { ...l, ...p } : l)) }));
  const move = (i: number, d: number) => setS((o) => {
    const ls = [...o.lectures]; const j = i + d; if (j < 0 || j >= ls.length) return o;
    [ls[i], ls[j]] = [ls[j], ls[i]]; return { ...o, lectures: ls.map((l, k) => ({ ...l, order: k })) };
  });
  const create = () => guard(async () => {
    const c = await api.create(title.trim() || 'Untitled course', desc, s);
    go({ name: 'forge', courseId: c.id });
  });
  const words = s.lectures.reduce((n, l) => n + l.text.split(/\s+/).length, 0);

  return (
    <div ref={root}>
      <section className="hero"><h1>Add your <span className="grad">course material</span></h1>
        <p className="muted">Udemy videos are DRM-protected, so LearnForge works from text you already have access to: caption files, transcripts and article text. Only use content you are entitled to use.</p></section>
      <div className="cols">
        <div className="glass card">
          <label htmlFor="t">Course title</label><input id="t" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Complete JavaScript Bootcamp" />
          <div style={{ height: 12 }} /><label htmlFor="d">What's it about? (optional)</label><input id="d" value={desc} onChange={(e) => setDesc(e.target.value)} />
          <div style={{ height: 16 }} />
          <div className={`drop ${over ? 'over' : ''}`} onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
            onDrop={(e) => { e.preventDefault(); setOver(false); addFiles(e.dataTransfer.files); }}>
            <div style={{ fontSize: '2rem' }}>📥</div><p>Drop .vtt .srt .txt .md .html files</p>
            <input ref={input} type="file" multiple hidden accept=".vtt,.srt,.txt,.md,.html,.htm" onChange={(e) => e.target.files && addFiles(e.target.files)} />
            <button className="btn" onClick={() => input.current?.click()}>Choose files</button>
          </div>
        </div>
        <div className="glass card">
          <label htmlFor="p">…or paste text (use <code># Section</code> and <code>## Lecture</code> markers)</label>
          <textarea id="p" value={paste} onChange={(e) => setPaste(e.target.value)} rows={9} placeholder={'# Basics\n## Variables\nA variable is…'} />
          <div className="actions"><button className="btn" disabled={busy || paste.trim().length < 20} onClick={addPaste}>Add pasted text</button></div>
        </div>
      </div>
      {err && <p role="alert" style={{ color: 'var(--bad)', marginTop: 12 }}>{err}</p>}
      <div className="glass card" style={{ marginTop: 16 }}>
        <h2>Lectures <span className="muted num" style={{ fontSize: '1rem' }}>{s.lectures.length} · {words.toLocaleString()} words</span></h2>
        {!s.lectures.length && <p className="muted">Nothing added yet.</p>}
        {s.lectures.map((l, i) => (
          <div className="lec" key={l.id}>
            <span className="muted num">{i + 1}</span>
            <input value={l.title} onChange={(e) => patch(l.id, { title: e.target.value })} aria-label="Lecture title" />
            <select value={l.kind} onChange={(e) => patch(l.id, { kind: e.target.value as LectureKind })} aria-label="Kind"><option value="video">🎬 video</option><option value="article">📄 article</option></select>
            <span className="muted num">{l.text.split(/\s+/).length}w</span>
            <button className="btn sm ghost" aria-label="Move up" onClick={() => move(i, -1)}>↑</button>
            <button className="btn sm ghost" aria-label="Move down" onClick={() => move(i, 1)}>↓</button>
            <button className="btn sm ghost" aria-label="Remove" onClick={() => setS((o) => ({ ...o, lectures: o.lectures.filter((x) => x.id !== l.id) }))}>✕</button>
          </div>
        ))}
        <div className="actions"><button className="btn primary" disabled={busy || !s.lectures.length} onClick={create}>⚒ Forge course</button>
          <button className="btn ghost" onClick={() => go({ name: 'dashboard' })}>Cancel</button></div>
      </div>
    </div>
  );
}
