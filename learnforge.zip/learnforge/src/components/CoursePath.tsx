import type { ReactElement } from 'react';
import { useEffect, useRef, useState } from 'react';
import { api } from '../api';
import { useStore, useProgress } from '../store/useStore';
import { courseProgress, milestoneUnlocked, moduleDone, moduleProgress, moduleUnlocked, resumeTarget } from '../lib/progress';
import { gsap, reveal, useGsap } from '../lib/gsapSetup';
import { ProgressRing } from './ProgressRing';
import { CoverageMap } from './CoverageMap';
import { MagneticButton } from './Shell';

export function CoursePath({ courseId, tab = 'path' }: { courseId: string; tab?: 'path' | 'coverage' }) {
  const { go, curricula, setCurriculum } = useStore();
  const cur = curricula[courseId], p = useProgress(courseId);
  const [title, setTitle] = useState('');
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => { if (!cur) api.curriculum(courseId).then(setCurriculum).catch(() => go({ name: 'forge', courseId })); }, [cur, courseId, go, setCurriculum]);
  useEffect(() => { api.courses().then((cs) => setTitle(cs.find((c) => c.id === courseId)?.title ?? '')).catch(() => {}); }, [courseId]);

  useGsap(root, () => {
    reveal('.hero > *'); reveal('.node', { stagger: 0.09, delay: 0.15 });
    gsap.from('.vline', { scaleY: 0, transformOrigin: 'top', duration: 1.6, ease: 'power2.inOut' });
    gsap.to('.dot.ms:not(.lock)', { y: -4, repeat: -1, yoyo: true, duration: 1.4, ease: 'sine.inOut' });
  }, [cur?.courseId, tab]);

  if (!cur) return <p className="muted">Loading…</p>;
  const pct = courseProgress(cur, p), next = resumeTarget(cur, p);
  const resume = () => {
    if (!next) return;
    go(next.kind === 'lesson' ? { name: 'lesson', courseId, moduleId: next.moduleId, idx: next.idx } : { name: 'milestone', courseId, msId: next.id });
  };

  const items = cur.modules.flatMap((m, i) => {
    const out: ReactElement[] = [];
    const unlocked = moduleUnlocked(cur, p, i), done = moduleDone(cur, p, m.id), mp = moduleProgress(cur, p, m.id);
    const isCur = unlocked && !done;
    out.push(
      <div className="node" key={m.id}>
        <div className={`dot ${done ? 'done' : ''} ${isCur ? 'cur' : ''} ${!unlocked ? 'lock' : ''}`}>{done ? '✓' : unlocked ? i + 1 : '🔒'}</div>
        <button className={`glass body ${!unlocked ? 'lock' : ''}`} disabled={!unlocked} onClick={() => go({ name: 'lesson', courseId, moduleId: m.id, idx: Math.max(0, m.stepIds.findIndex((id) => !p.done[id])) })}>
          <h3>{m.title}</h3><p className="muted" style={{ margin: 0 }}>{m.goal}</p>
          <p style={{ margin: '8px 0 0', fontSize: '.85rem' }}>🔨 {m.projectSlice}</p>
          <div className="bar"><i style={{ width: `${mp * 100}%` }} /></div>
        </button>
      </div>);
    for (const ms of cur.milestones.filter((x) => x.afterModuleId === m.id)) {
      const open = milestoneUnlocked(cur, p, ms.id), fin = p.milestones[ms.id]?.done;
      out.push(
        <div className="node" key={ms.id}>
          <div className={`dot ms ${!open ? 'lock' : ''}`}>{fin ? '🏆' : open ? '★' : '🔒'}</div>
          <button className={`glass body ${!open ? 'lock' : ''}`} disabled={!open} onClick={() => go({ name: 'milestone', courseId, msId: ms.id })}>
            <span className="pill ai">Milestone project · +{ms.xp} XP</span><h3 style={{ marginTop: 8 }}>{ms.title}</h3>
            <p className="muted" style={{ margin: 0 }}>{ms.brief}</p>
          </button>
        </div>);
    }
    return out;
  });

  return (
    <div ref={root}>
      <section className="hero" style={{ paddingBottom: 12 }}>
        <div style={{ display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap' }}>
          <ProgressRing value={pct} size={96} stroke={9} />
          <div style={{ flex: 1, minWidth: 240 }}><h1 style={{ fontSize: 'clamp(1.6rem,3.5vw,2.6rem)' }}>{title || 'Your course'}</h1>
            <p className="muted" style={{ margin: 0 }}>🧱 {cur.spineProject}</p></div>
          {next && <MagneticButton className="btn primary" onClick={resume}>▶ {pct > 0 ? 'Resume' : 'Start building'}</MagneticButton>}
        </div>
        <div style={{ display: 'flex', gap: 8, marginTop: 12, flexWrap: 'wrap' }}>
          <span className="pill">{cur.modules.length} modules</span><span className="pill">{cur.steps.length} steps</span>
          <span className="pill good">Coverage {Math.round(cur.coverage.score * 100)}%</span>
          {cur.coverage.fixed.length > 0 && <span className="pill warn">✨ {cur.coverage.fixed.length} AI-reinforced</span>}
        </div>
      </section>
      <div className="tabs" role="tablist">
        <button role="tab" className={`tab ${tab === 'path' ? 'on' : ''}`} onClick={() => go({ name: 'path', courseId, tab: 'path' })}>Journey</button>
        <button role="tab" className={`tab ${tab === 'coverage' ? 'on' : ''}`} onClick={() => go({ name: 'path', courseId, tab: 'coverage' })}>Coverage map</button>
      </div>
      {tab === 'path' ? (
        <div className="journey">
          <div className="vline" aria-hidden />
          {items}
        </div>
      ) : <CoverageMap cur={cur} />}
    </div>
  );
}
