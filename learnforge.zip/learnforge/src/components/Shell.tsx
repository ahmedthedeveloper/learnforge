import { useEffect, useRef, type ReactNode } from 'react';
import { useStore } from '../store/useStore';
import { levelProgress } from '../lib/xp';
import { countUp, gsap, reduced, useGsap, magnetic } from '../lib/gsapSetup';
import { fireConfetti } from '../lib/confetti';

export function MeshBackground() {
  const ref = useRef<HTMLDivElement>(null);
  useGsap(ref, () => {
    gsap.utils.toArray<HTMLElement>('i').forEach((el, k) => {
      gsap.to(el, { x: 'random(-12vw,12vw)', y: 'random(-10vh,10vh)', scale: 'random(0.85,1.25)', duration: 14 + k * 4, ease: 'sine.inOut', repeat: -1, yoyo: true });
    });
  });
  return <div className="mesh" ref={ref} aria-hidden><i /><i /><i /></div>;
}

export function XPBar() {
  const xp = useStore((s) => s.xp), streak = useStore((s) => s.streak);
  const p = levelProgress(xp);
  const fill = useRef<HTMLDivElement>(null), num = useRef<HTMLSpanElement>(null);
  useEffect(() => {
    if (reduced()) { if (fill.current) fill.current.style.width = p.pct * 100 + '%'; }
    else gsap.to(fill.current, { width: p.pct * 100 + '%', duration: 0.9, ease: 'power3.out' });
    countUp(num.current, xp, ' XP', 0.8);
  }, [xp, p.pct]);
  return (
    <div className="xpbar" title={`${p.into}/${p.need} XP to level ${p.level + 1}`}>
      <span className="pill">Lv <b className="num">{p.level}</b></span>
      <div className="track"><div className="fill" ref={fill} /></div>
      <span className="num muted" ref={num} style={{ fontSize: '.8rem', minWidth: 58 }}>{xp} XP</span>
      {streak > 0 && <span className="pill warn" title="day streak">🔥 {streak}</span>}
    </div>
  );
}

export function Toasts() {
  const toasts = useStore((s) => s.toasts), level = useStore((s) => s.levelUp), clear = useStore((s) => s.clearLevelUp);
  const box = useRef<HTMLDivElement>(null), lu = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const last = box.current?.lastElementChild;
    if (last && !reduced()) gsap.from(last, { x: 80, autoAlpha: 0, duration: 0.5, ease: 'back.out(1.8)' });
  }, [toasts.length]);
  useEffect(() => {
    if (level === null || !lu.current) return;
    fireConfetti(220);
    if (!reduced()) {
      const tl = gsap.timeline();
      tl.from(lu.current, { autoAlpha: 0, duration: 0.3 })
        .from(lu.current.querySelectorAll('.pop'), { scale: 0.3, autoAlpha: 0, rotate: -8, stagger: 0.15, duration: 0.7, ease: 'back.out(2)' });
    }
    const t = setTimeout(clear, 3200);
    return () => clearTimeout(t);
  }, [level, clear]);
  return (
    <>
      <div className="toasts" ref={box} aria-live="polite">{toasts.map((t) => <div key={t.id} className="toast">{t.text}</div>)}</div>
      {level !== null && (
        <div className="levelup" ref={lu} onClick={clear} role="dialog" aria-label="Level up">
          <div><p className="pop muted" style={{ letterSpacing: '.3em' }}>LEVEL UP</p><h1 className="pop grad">Level {level}</h1><p className="pop muted">Keep building ✨</p></div>
        </div>
      )}
    </>
  );
}

export function MagneticButton(props: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const ref = useRef<HTMLButtonElement>(null);
  useEffect(() => (ref.current ? magnetic(ref.current) : undefined), []);
  return <button ref={ref} {...props} />;
}

export function Shell({ children, mode }: { children: ReactNode; mode?: string }) {
  const go = useStore((s) => s.go), theme = useStore((s) => s.theme), setTheme = useStore((s) => s.setTheme);
  return (
    <>
      <MeshBackground />
      <div className="shell">
        <header className="top">
          <button className="logo" onClick={() => go({ name: 'dashboard' })}><b>⚒</b>LearnForge</button>
          {mode && <span className={`pill ${mode === 'claude' ? 'good' : 'ai'}`}>{mode === 'claude' ? '● Claude' : '● Offline mode'}</span>}
          <div className="spacer" />
          <XPBar />
          <button className="btn sm ghost" aria-label="Toggle theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>{theme === 'dark' ? '☀️' : '🌙'}</button>
        </header>
        <main>{children}</main>
      </div>
      <Toasts />
    </>
  );
}
