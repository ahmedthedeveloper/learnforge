import { useEffect, useRef } from 'react';
import { gsap, reduced } from '../lib/gsapSetup';

export function ProgressRing({ value, size = 64, stroke = 7 }: { value: number; size?: number; stroke?: number }) {
  const ref = useRef<SVGCircleElement>(null), label = useRef<HTMLSpanElement>(null);
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  useEffect(() => {
    const target = c * (1 - Math.min(1, value));
    if (reduced()) { ref.current?.setAttribute('stroke-dashoffset', String(target)); return; }
    const o = { v: parseFloat(label.current?.dataset.v ?? '0') };
    const t = gsap.to(ref.current, { attr: { 'stroke-dashoffset': target }, duration: 1.1, ease: 'elastic.out(1,0.7)' });
    const n = gsap.to(o, { v: value * 100, duration: 1, ease: 'power2.out', onUpdate: () => {
      if (label.current) { label.current.textContent = Math.round(o.v) + '%'; label.current.dataset.v = String(o.v); } } });
    return () => { t.kill(); n.kill(); };
  }, [value, c]);
  return (
    <div className="ring" style={{ width: size, height: size }} role="img" aria-label={`${Math.round(value * 100)}% complete`}>
      <svg width={size} height={size}>
        <defs><linearGradient id="rg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#7c5cff" /><stop offset="1" stopColor="#22d3ee" /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={stroke} />
        <circle ref={ref} cx={size / 2} cy={size / 2} r={r} fill="none" stroke="url(#rg)" strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c} />
      </svg>
      <span ref={label} className="num">{Math.round(value * 100)}%</span>
    </div>
  );
}
