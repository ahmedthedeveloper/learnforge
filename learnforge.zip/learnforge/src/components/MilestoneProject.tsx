import { useRef, useState } from 'react';
import { useStore, useProgress } from '../store/useStore';
import { reveal, useGsap } from '../lib/gsapSetup';
import { fireConfetti } from '../lib/confetti';

export function MilestoneProject({ courseId, msId }: { courseId: string; msId: string }) {
  const { go, curricula, submitMilestone } = useStore();
  const cur = curricula[courseId], p = useProgress(courseId);
  const ms = cur?.milestones.find((m) => m.id === msId);
  const saved = p.milestones[msId];
  const [req, setReq] = useState<boolean[]>([]), [rubric, setRubric] = useState<boolean[]>(saved?.rubric ?? []), [notes, setNotes] = useState(saved?.notes ?? '');
  const root = useRef<HTMLDivElement>(null);
  useGsap(root, () => reveal('.glass, h1, .hero p'), [msId]);
  if (!cur || !ms) return <p className="muted">Loading…</p>;
  const reqs = ms.requirements.map((_, i) => req[i] ?? !!saved?.done), rub = ms.rubric.map((_, i) => rubric[i] ?? !!saved?.done);
  const ready = reqs.every(Boolean) && rub.filter(Boolean).length >= Math.ceil(ms.rubric.length / 2) && notes.trim().length >= 10;
  return (
    <div ref={root}>
      <section className="hero">
        <span className="pill ai">🏆 Milestone project · +{ms.xp} XP</span>
        <h1 style={{ marginTop: 12 }}>{ms.title}</h1><p className="muted">{ms.brief}</p>
      </section>
      <div className="cols">
        <div className="glass card"><h2>Requirements</h2>
          {ms.requirements.map((r, i) => <label className="check" key={i}><input type="checkbox" checked={reqs[i]} onChange={(e) => setReq(reqs.map((v, k) => (k === i ? e.target.checked : v)))} />{r}</label>)}
          <h2 style={{ marginTop: 24 }}>Self-review rubric</h2>
          {ms.rubric.map((r, i) => <label className="check" key={i}><input type="checkbox" checked={rub[i]} onChange={(e) => setRubric(rub.map((v, k) => (k === i ? e.target.checked : v)))} />{r}</label>)}
        </div>
        <div className="glass card"><h2>Your build log</h2>
          <textarea rows={9} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Link, repo, or what you built and learned…" />
          <div className="actions">
            <button className="btn primary" disabled={!ready} onClick={() => { submitMilestone(cur, ms.id, rub, notes); fireConfetti(200); go({ name: 'path', courseId }); }}>
              {saved?.done ? 'Update submission' : 'Submit milestone 🎉'}</button>
            <button className="btn ghost" onClick={() => go({ name: 'path', courseId })}>Back</button>
          </div>
          {!ready && <p className="muted" style={{ fontSize: '.85rem' }}>Tick all requirements, at least half the rubric, and write a short log.</p>}
        </div>
      </div>
    </div>
  );
}
