import { useEffect, useRef, useState } from 'react';
import { useStore, useProgress } from '../store/useStore';
import { gsap, reduced, useGsap } from '../lib/gsapSetup';
import { fireConfetti } from '../lib/confetti';
import { Md } from '../lib/md';
import { CodeBlock } from './CodeBlock';
import { Quiz } from './Quiz';
import { moduleUnlocked } from '../lib/progress';

const ICON = { explain: '💡', build: '🔨', check: '🎯', reflect: '🪞' } as const;

export function LessonPlayer({ courseId, moduleId, idx = 0 }: { courseId: string; moduleId: string; idx?: number }) {
  const { go, curricula, completeStep, recordQuiz, useHint, setNote } = useStore();
  const cur = curricula[courseId], p = useProgress(courseId);
  const [i, setI] = useState(idx), [hintN, setHintN] = useState(0), [built, setBuilt] = useState(false);
  const card = useRef<HTMLDivElement>(null);
  const mod = cur?.modules.find((m) => m.id === moduleId);
  const steps = mod ? mod.stepIds.map((id) => cur.steps.find((s) => s.id === id)!) : [];
  const step = steps[Math.min(i, steps.length - 1)];
  const done = !!step && !!p.done[step.id];
  const note = step ? p.notes[step.id] ?? '' : '';

  useEffect(() => { setHintN(0); setBuilt(false); }, [step?.id]);
  useGsap(card, () => {
    gsap.from(card.current, { autoAlpha: 0, x: 40, duration: 0.5, ease: 'power3.out' });
    gsap.from('.step .meta > *, .step h2, .step .md > *, .step .code, .step .task', { autoAlpha: 0, y: 14, stagger: 0.05, duration: 0.5, delay: 0.1, clearProps: 'all' });
  }, [step?.id]);

  const next = () => {
    if (i < steps.length - 1) setI(i + 1);
    else {
      const mi = cur.modules.findIndex((m) => m.id === moduleId);
      const gate = cur.milestones.find((m) => m.afterModuleId === moduleId);
      fireConfetti(120);
      if (gate && gate.moduleIds.every((id) => cur.modules.find((m) => m.id === id)!.stepIds.every((s) => useStore.getState().progress[courseId]?.done[s]))) go({ name: 'milestone', courseId, msId: gate.id });
      else if (mi + 1 < cur.modules.length && moduleUnlocked(cur, useStore.getState().progress[courseId] ?? p, mi + 1)) go({ name: 'lesson', courseId, moduleId: cur.modules[mi + 1].id, idx: 0 });
      else go({ name: 'path', courseId });
    }
  };
  const finish = () => { completeStep(cur, step); next(); };
  const canFinish = !step ? false : done || step.type === 'explain' || (step.type === 'build' && built)
    || (step.type === 'reflect' && note.trim().length >= 10) || (step.type === 'check' && p.quiz[step.id]?.correct);

  useEffect(() => {
    const on = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement).matches('input,textarea,select')) return;
      if (e.key === 'j') setI((x) => Math.min(steps.length - 1, x + 1));
      if (e.key === 'k') setI((x) => Math.max(0, x - 1));
      if (e.key === 'h' && step && hintN < step.hints.length) { setHintN(hintN + 1); useHint(courseId, step.id); }
    };
    addEventListener('keydown', on); return () => removeEventListener('keydown', on);
  }, [steps.length, step?.id, hintN]); // eslint-disable-line react-hooks/exhaustive-deps

  if (!cur || !mod || !step) return <p className="muted">Loading…</p>;
  return (
    <div className="lesson">
      <nav className="glass rail" aria-label="Steps">
        <button className="btn sm ghost" onClick={() => go({ name: 'path', courseId })}>← Journey</button>
        <h3 style={{ margin: '12px 8px 8px' }}>{mod.title}</h3>
        {steps.map((s, k) => (
          <button key={s.id} className={`ri ${k === i ? 'on' : ''} ${p.done[s.id] ? 'done' : ''}`} onClick={() => setI(k)}>
            <span className="ic">{p.done[s.id] ? '✓' : ICON[s.type]}</span><span>{s.title}</span></button>
        ))}
      </nav>
      <div className="glass step" ref={card}>
        <div className="meta">
          <span className="pill">{ICON[step.type]} {step.type}</span>
          {step.origin === 'ai-fix' && <span className="pill warn" title="The AI strengthened a thin or missing part of the original course">✨ AI-fixed</span>}
          <span className="pill num">{i + 1}/{steps.length}</span><span className="pill">+{step.xp} XP</span>
        </div>
        <h2>{step.title}</h2>
        {step.body && <Md text={step.body} />}
        {step.task && <div className="task"><b>Your turn:</b> {step.task}</div>}
        {step.code && <CodeBlock code={step.code} language={step.language} />}
        {step.type === 'build' && (
          <>
            <label htmlFor="ws">Your workspace (notes / code you wrote)</label>
            <textarea id="ws" value={note} onChange={(e) => setNote(courseId, step.id, e.target.value)} placeholder="Paste or jot what you built…" />
            {step.hints.slice(0, hintN).map((h, k) => <div className="hint" key={k}>💡 {h}</div>)}
            {!done && <label className="check" style={{ marginTop: 12 }}><input type="checkbox" checked={built} onChange={(e) => setBuilt(e.target.checked)} /> I built it and it works</label>}
          </>
        )}
        {step.type === 'check' && step.quiz && <Quiz quiz={step.quiz} onAnswer={(ok) => recordQuiz(courseId, step.id, ok)} />}
        {step.type === 'reflect' && (
          <><textarea value={note} onChange={(e) => setNote(courseId, step.id, e.target.value)} placeholder="Write a few sentences (10+ characters)…" /></>
        )}
        <div className="actions">
          <button className="btn ghost" disabled={i === 0} onClick={() => setI(i - 1)}>← Back</button>
          {step.type === 'build' && hintN < step.hints.length && !done &&
            <button className="btn" onClick={() => { setHintN(hintN + 1); useHint(courseId, step.id); }}>Hint ({hintN}/{step.hints.length})</button>}
          <div className="spacer" />
          {done ? <button className="btn primary" onClick={next}>Next →</button>
            : <button className="btn primary" disabled={!canFinish} onClick={finish}>{step.type === 'explain' ? 'Got it → build' : 'Complete step ✓'}</button>}
        </div>
        <p className="muted" style={{ fontSize: '.75rem', marginTop: 16 }}>Shortcuts: J next · K back · H hint{reduced() ? '' : ''}</p>
      </div>
    </div>
  );
}
