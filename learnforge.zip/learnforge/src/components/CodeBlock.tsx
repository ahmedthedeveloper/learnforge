import { useState } from 'react';

export function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="code">
      <button className="btn sm" onClick={async () => { try { await navigator.clipboard.writeText(code); setCopied(true); setTimeout(() => setCopied(false), 1200); } catch { /* clipboard unavailable */ } }}>
        {copied ? 'Copied ✓' : language ?? 'Copy'}</button>
      <pre><code>{code}</code></pre>
    </div>
  );
}
