import { useState } from 'react';
import type { Curriculum } from '../../shared/types';

export function CoverageMap({ cur }: { cur: Curriculum }) {
  const [sel, setSel] = useState<string | null>(null);
  const concept = cur.concepts.find((c) => c.id === sel);
  const steps = concept ? cur.coverage.map[concept.id].map((id) => cur.steps.find((s) => s.id === id)!) : [];
  return (
    <div>
      <p className="muted">Every idea found in the original course and where it is taught. <span className="pill good">solid</span> <span className="pill warn">AI-reinforced</span> <span className="pill" style={{ color: 'var(--bad)' }}>missing</span></p>
      <div className="cmap">
        {cur.concepts.map((c) => {
          const miss = cur.coverage.missing.includes(c.id), fixed = cur.coverage.fixed.includes(c.id);
          return <button key={c.id} className={`cc ${miss ? 'miss' : fixed ? 'fixed' : ''}`} onClick={() => setSel(c.id)}>
            <b>{c.name}</b><div className="muted" style={{ fontSize: '.78rem' }}>{cur.coverage.map[c.id].length} steps{fixed ? ' · ✨ AI-reinforced' : ''}</div></button>;
        })}
      </div>
      {concept && (
        <div className="glass card" style={{ marginTop: 16 }}>
          <h3>{concept.name}</h3><p>{concept.summary}</p>
          <p className="muted"><i>Source: “{concept.sourceQuote}”</i></p>
          <p>Taught in: {steps.map((s) => s.title).join(' · ') || 'nowhere yet'}</p>
          {cur.gaps.filter((g) => g.conceptId === concept.id).map((g) => <p key={g.id} className="hint">⚠ {g.kind}: {g.note}</p>)}
        </div>
      )}
    </div>
  );
}
