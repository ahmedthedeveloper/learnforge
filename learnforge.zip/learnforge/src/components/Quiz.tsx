import { useEffect, useRef, useState } from 'react';
import type { Quiz as QuizT } from '../../shared/types';
import { gsap, reduced } from '../lib/gsapSetup';
import { fireConfetti } from '../lib/confetti';

export function Quiz({ quiz, onAnswer }: { quiz: QuizT; onAnswer: (correct: boolean) => void }) {
  const [picked, setPicked] = useState<number | null>(null), [solved, setSolved] = useState(false);
  const refs = useRef<(HTMLButtonElement | null)[]>([]);
  useEffect(() => { setPicked(null); setSolved(false); }, [quiz]);
  const pick = (i: number) => {
    if (solved) return;
    setPicked(i);
    const ok = i === quiz.answer, el = refs.current[i];
    if (ok) setSolved(true);
    if (!reduced() && el) {
      if (ok) gsap.fromTo(el, { scale: 0.96 }, { scale: 1, duration: 0.6, ease: 'elastic.out(1.2,0.4)' });
      else gsap.fromTo(el, { x: -8 }, { x: 0, duration: 0.5, ease: 'elastic.out(1,0.2)' });
    }
    if (ok) fireConfetti(40);
    onAnswer(ok);
  };
  return (
    <div>
      <p><b>{quiz.question}</b></p>
      <div className="opts">
        {quiz.options.map((o, i) => (
          <button key={i} ref={(el) => { refs.current[i] = el; }} disabled={solved && i !== picked}
            className={`opt ${picked === i ? (i === quiz.answer ? 'right' : 'wrong') : ''}`} onClick={() => pick(i)}>{o}</button>
        ))}
      </div>
      {picked !== null && <p className={picked === quiz.answer ? '' : 'muted'}>{picked === quiz.answer ? `✅ ${quiz.explanation}` : 'Not quite — try again.'}</p>}
    </div>
  );
}
