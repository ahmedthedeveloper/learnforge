import type { Course, Curriculum, Lecture, PipelineEvent, Section } from '../shared/types';

export interface CourseSummary extends Omit<Course, 'lectures'> { lectures: Lecture[]; forged: boolean }
export interface Structure { sections: Section[]; lectures: Lecture[] }

async function j<T>(r: Response): Promise<T> {
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((d as { error?: string }).error ?? `Request failed (${r.status})`);
  return d as T;
}
const post = (url: string, body: unknown) =>
  fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

export const api = {
  health: () => fetch('/api/health').then((r) => j<{ aiMode: 'claude' | 'offline'; model: string }>(r)),
  courses: () => fetch('/api/courses').then((r) => j<CourseSummary[]>(r)),
  ingest: (files: File[]) => { const f = new FormData(); files.forEach((x) => f.append('files', x)); return fetch('/api/ingest', { method: 'POST', body: f }).then((r) => j<Structure>(r)); },
  paste: (text: string) => post('/api/paste', { text }).then((r) => j<Structure>(r)),
  create: (title: string, description: string, s: Structure) => post('/api/courses', { title, description, ...s }).then((r) => j<Course>(r)),
  remove: (id: string) => fetch(`/api/courses/${id}`, { method: 'DELETE' }).then((r) => j<{ ok: true }>(r)),
  curriculum: (id: string) => fetch(`/api/courses/${id}/curriculum`).then((r) => j<Curriculum>(r)),
  async forge(id: string, onEvent: (e: PipelineEvent) => void, signal?: AbortSignal) {
    const res = await fetch(`/api/courses/${id}/forge`, { method: 'POST', signal });
    if (!res.ok || !res.body) throw new Error('Could not start forging');
    const reader = res.body.getReader(), dec = new TextDecoder();
    let buf = '';
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const chunk = buf.slice(0, i); buf = buf.slice(i + 2);
        if (chunk.startsWith('data: ')) onEvent(JSON.parse(chunk.slice(6)));
      }
    }
  },
};
