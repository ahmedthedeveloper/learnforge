import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Curriculum, Step } from '../../shared/types';
import { dayKey, daysBetween, levelOf } from '../lib/xp';

export type Route =
  | { name: 'dashboard' } | { name: 'import' } | { name: 'forge'; courseId: string }
  | { name: 'path'; courseId: string; tab?: 'path' | 'coverage' }
  | { name: 'lesson'; courseId: string; moduleId: string; idx?: number }
  | { name: 'milestone'; courseId: string; msId: string };

export interface CourseProgress {
  done: Record<string, true>;
  quiz: Record<string, { tries: number; correct: boolean }>;
  hints: Record<string, number>;
  notes: Record<string, string>;
  milestones: Record<string, { done: boolean; rubric: boolean[]; notes: string }>;
}
export const emptyProgress = (): CourseProgress => ({ done: {}, quiz: {}, hints: {}, notes: {}, milestones: {} });

export const BADGES: Record<string, { label: string; icon: string }> = {
  firstBuild: { label: 'First Build', icon: '🔨' }, streak3: { label: '3-day streak', icon: '🔥' },
  streak7: { label: '7-day streak', icon: '🌋' }, moduleMaster: { label: 'Module Master', icon: '🎓' },
  milestoneMaker: { label: 'Milestone Maker', icon: '🏆' }, zeroHints: { label: 'Zero Hints', icon: '🧠' },
  completionist: { label: 'Completionist', icon: '💎' },
};

interface Toast { id: number; text: string }
interface State {
  route: Route;
  go: (r: Route) => void;
  xp: number; streak: number; lastDay: string; badges: string[];
  progress: Record<string, CourseProgress>;
  theme: 'dark' | 'light'; reducedMotion: boolean;
  toasts: Toast[]; levelUp: number | null;
  curricula: Record<string, Curriculum>;
  setCurriculum: (c: Curriculum) => void;
  toast: (t: string) => void; dismissToast: (id: number) => void; clearLevelUp: () => void;
  setTheme: (t: 'dark' | 'light') => void; setReducedMotion: (v: boolean) => void;
  completeStep: (cur: Curriculum, step: Step) => number;
  recordQuiz: (courseId: string, stepId: string, correct: boolean) => void;
  useHint: (courseId: string, stepId: string) => void;
  setNote: (courseId: string, stepId: string, text: string) => void;
  submitMilestone: (cur: Curriculum, msId: string, rubric: boolean[], notes: string) => void;
  resetCourse: (courseId: string) => void; resetAll: () => void;
}

let tid = 0;
const cp = (s: State, id: string) => s.progress[id] ?? emptyProgress();

export const useStore = create<State>()(persist((set, get) => {
  const award = (amount: number, reason: string) => {
    const s = get();
    const before = levelOf(s.xp), xp = s.xp + amount, after = levelOf(xp);
    set({ xp, levelUp: after > before ? after : s.levelUp });
    s.toast(`+${amount} XP · ${reason}`);
  };
  const touchStreak = () => {
    const s = get(), today = dayKey();
    if (s.lastDay === today) return;
    const streak = s.lastDay && daysBetween(s.lastDay, today) === 1 ? s.streak + 1 : 1;
    set({ streak, lastDay: today });
    if (streak >= 3) get().toast(`🔥 ${streak}-day streak`);
  };
  const badge = (k: string) => {
    if (get().badges.includes(k)) return;
    set({ badges: [...get().badges, k] });
    get().toast(`${BADGES[k].icon} Badge: ${BADGES[k].label}`);
  };
  return {
    route: { name: 'dashboard' }, go: (route) => { set({ route }); scrollTo({ top: 0 }); },
    xp: 0, streak: 0, lastDay: '', badges: [], progress: {}, theme: 'dark', reducedMotion: false,
    toasts: [], levelUp: null, curricula: {},
    setCurriculum: (c) => set((s) => ({ curricula: { ...s.curricula, [c.courseId]: c } })),
    toast: (text) => {
      const id = ++tid;
      set((s) => ({ toasts: [...s.toasts, { id, text }] }));
      setTimeout(() => get().dismissToast(id), 2600);
    },
    dismissToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
    clearLevelUp: () => set({ levelUp: null }),
    setTheme: (theme) => set({ theme }), setReducedMotion: (reducedMotion) => set({ reducedMotion }),

    completeStep: (cur, step) => {
      const s = get(), p = cp(s, cur.courseId);
      if (p.done[step.id]) return 0;
      const q = p.quiz[step.id], hints = p.hints[step.id] ?? 0;
      let gain = step.xp;
      if (step.type === 'check' && q?.tries === 1) gain += 5;
      if (step.type === 'build' && hints === 0) gain += 5;
      const done = { ...p.done, [step.id]: true as const };
      set({ progress: { ...s.progress, [cur.courseId]: { ...p, done } } });
      touchStreak(); award(gain, step.type === 'check' && q?.tries === 1 ? 'first try!' : step.title);
      if (step.type === 'build') badge('firstBuild');
      if (step.type === 'build' && hints === 0) badge('zeroHints');
      if (get().streak >= 7) badge('streak7'); else if (get().streak >= 3) badge('streak3');
      const mod = cur.modules.find((m) => m.id === step.moduleId)!;
      if (mod.stepIds.every((id) => done[id])) badge('moduleMaster');
      if (cur.steps.every((x) => done[x.id])) badge('completionist');
      return gain;
    },
    recordQuiz: (id, stepId, correct) => set((s) => {
      const p = cp(s, id), prev = p.quiz[stepId];
      return { progress: { ...s.progress, [id]: { ...p, quiz: { ...p.quiz, [stepId]: { tries: (prev?.tries ?? 0) + 1, correct: correct || !!prev?.correct } } } } };
    }),
    useHint: (id, stepId) => set((s) => {
      const p = cp(s, id);
      return { progress: { ...s.progress, [id]: { ...p, hints: { ...p.hints, [stepId]: (p.hints[stepId] ?? 0) + 1 } } } };
    }),
    setNote: (id, stepId, text) => set((s) => {
      const p = cp(s, id);
      return { progress: { ...s.progress, [id]: { ...p, notes: { ...p.notes, [stepId]: text } } } };
    }),
    submitMilestone: (cur, msId, rubric, notes) => {
      const s = get(), p = cp(s, cur.courseId), ms = cur.milestones.find((m) => m.id === msId)!;
      const first = !p.milestones[msId]?.done;
      set({ progress: { ...s.progress, [cur.courseId]: { ...p, milestones: { ...p.milestones, [msId]: { done: true, rubric, notes } } } } });
      touchStreak();
      if (first) { award(ms.xp, `Milestone: ${ms.title}`); badge('milestoneMaker'); }
    },
    resetCourse: (id) => set((s) => { const progress = { ...s.progress }; delete progress[id]; return { progress }; }),
    resetAll: () => set({ xp: 0, streak: 0, lastDay: '', badges: [], progress: {} }),
  };
}, {
  name: 'learnforge-v1', version: 1,
  partialize: (s) => ({ xp: s.xp, streak: s.streak, lastDay: s.lastDay, badges: s.badges, progress: s.progress, theme: s.theme, reducedMotion: s.reducedMotion }),
}));

export const useProgress = (courseId: string) => useStore((s) => s.progress[courseId]) ?? emptyProgress();
