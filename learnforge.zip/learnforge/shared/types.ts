export type LectureKind = 'video' | 'article';

export interface Lecture {
  id: string;
  sectionId: string;
  title: string;
  kind: LectureKind;
  text: string;
  order: number;
}
export interface Section {
  id: string;
  title: string;
  order: number;
}
export interface Course {
  id: string;
  title: string;
  description: string;
  sections: Section[];
  lectures: Lecture[];
  createdAt: number;
}

export type Quality = 'solid' | 'thin' | 'missing-context';
export interface Concept {
  id: string;
  lectureId: string;
  name: string;
  summary: string;
  sourceQuote: string;
  difficulty: number;
  quality: Quality;
}
export type GapKind = 'thin' | 'visual-only' | 'undefined-term' | 'missing-prereq' | 'error';
export interface Gap {
  id: string;
  lectureId: string;
  kind: GapKind;
  note: string;
  conceptId?: string;
}
export interface Analysis {
  concepts: Concept[];
  gaps: Gap[];
}

export interface Quiz {
  question: string;
  options: string[];
  answer: number;
  explanation: string;
}
export type StepType = 'explain' | 'build' | 'check' | 'reflect';
export interface Step {
  id: string;
  moduleId: string;
  type: StepType;
  title: string;
  body: string;
  code?: string;
  language?: string;
  task?: string;
  hints: string[];
  quiz?: Quiz;
  conceptIds: string[];
  origin: 'course' | 'ai-fix';
  xp: number;
}
export interface Module {
  id: string;
  title: string;
  goal: string;
  projectSlice: string;
  conceptIds: string[];
  stepIds: string[];
}
export interface Milestone {
  id: string;
  title: string;
  brief: string;
  afterModuleId: string;
  moduleIds: string[];
  requirements: string[];
  rubric: string[];
  conceptIds: string[];
  xp: number;
}
export interface Coverage {
  map: Record<string, string[]>;
  fixed: string[];
  missing: string[];
  score: number;
}
export interface Curriculum {
  courseId: string;
  mode: 'claude' | 'offline';
  spineProject: string;
  modules: Module[];
  milestones: Milestone[];
  steps: Step[];
  concepts: Concept[];
  gaps: Gap[];
  coverage: Coverage;
  createdAt: number;
}

export interface PipelineEvent {
  stage: 'parse' | 'analyze' | 'design' | 'lessons' | 'audit' | 'done' | 'error';
  current: number;
  total: number;
  message: string;
  curriculum?: Curriculum;
}

export const STEP_XP: Record<StepType, number> = { explain: 5, build: 15, check: 10, reflect: 5 };
