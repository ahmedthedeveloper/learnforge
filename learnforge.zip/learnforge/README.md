# LearnForge

Turn a course (lecture transcripts + articles) into project-based, build-while-explaining lessons
with progress tracking, milestone projects and a coverage audit. See [PLAN.md](PLAN.md).

```bash
npm install
npm run dev                         # web on :5173, API on :8787
ANTHROPIC_API_KEY=sk-... npm run dev   # Claude mode (LF_MODEL overrides the model)
npm run build && npm start          # production, serves dist/ on :8787
npm run smoke                       # end-to-end API test (offline mode)
```

Without an API key the app runs in **offline mode**: a heuristic generator, good for trying the UX.

See [SETUP.md](SETUP.md) for the step-by-step guide.

## Getting course content in
Udemy videos are DRM-protected and there is no content API, so LearnForge takes text you can access:
caption files (`.vtt`/`.srt`), transcripts, article text (`.txt`/`.md`/`.html`) or pasted text with
`# Section` / `## Lecture` markers. Name files like `S01_L02 - Title.vtt` to group them into sections.
Only use content you are entitled to use.
